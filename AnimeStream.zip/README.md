# AnimeStream

A custom Android YouTube streaming app that fetches low-resolution video from YouTube and upscales it on-device using **libmpv's** shader pipeline. Real Anime4K, FSRCNNX, ArtCNN, and RAVU shaders run on your Mali-G610 GPU — same upscaling quality as mpv-android, in a cleaner app shell.

**Target device:** OPPO Reno 11F 5G (Dimensity 7050, Mali-G610 MC4, arm64-v8a, Android 13)
**Personal use only** — not for Play Store.

---

## ⚠️ You MUST provide libmpv before this app will play anything

The Kotlin code is complete and compiles, but **`libmpv.so` and `libplayer.so` cannot be fetched from Maven**. You need to obtain them manually (two methods below) and drop them into the project before the GitHub Actions build will produce a working APK.

Without these files:
- The build will **succeed** (the .so files are just empty placeholders)
- The app will **launch** and show the home screen
- The app will **fail to play** video — you'll see an error toast: *"libmpv native library not loaded"*

---

## How to obtain the libmpv AAR + .so files

### Method 1 (recommended, easy): Extract from a pre-built mpv-android APK

1. Download the latest mpv-android APK from the [official releases page](https://github.com/mpv-android/mpv-android/releases).
2. Open it as a ZIP file (APKs are ZIPs):
   ```
   unzip mpv-android-vX.Y.Z-arm64-v8a.apk -d mpv-android-extracted
   ```
3. Find the native libraries:
   ```
   ls mpv-android-extracted/lib/arm64-v8a/
   # → libmpv.so  libplayer.so  (and others — copy only these two)
   ```
4. Copy them into your project:
   ```
   cp mpv-android-extracted/lib/arm64-v8a/libmpv.so    app/src/main/jniLibs/arm64-v8a/
   cp mpv-android-extracted/lib/arm64-v8a/libplayer.so app/src/main/jniLibs/arm64-v8a/
   ```
5. The Kotlin wrapper (`MPVLib.kt`) is already included in this project — it matches the JNI symbols in mpv-android's `libplayer.so`. Don't change the function names.

**Note:** If the mpv-android release uses a newer JNI symbol set than this `MPVLib.kt` expects, you'll get `UnsatisfiedLinkError` at runtime. To fix, copy the latest `MPVLib.kt` from [mpv-android's repo](https://github.com/mpv-android/mpv-android/blob/master/app/src/main/java/is/xyz/mpv/MPVLib.kt) and adapt the package name.

### Method 2 (advanced): Build libmpv from source with mpv-android buildscripts

This produces a fresh AAR + .so files matched to the latest mpv-android code.

1. Clone mpv-android on a Linux machine (or WSL2):
   ```
   git clone https://github.com/mpv-android/mpv-android.git
   cd mpv-android
   ```
2. Read `BUILD.md` — it lists required SDK/NDK versions and Docker setup.
3. Run the build:
   ```
   cd buildscripts
   ./buildall.sh
   ```
   This produces:
   - `buildscripts/libmpv-prefix/lib/libmpv.so`
   - `app/src/main/jniLibs/arm64-v8a/libmpv.so`
   - `app/src/main/jniLibs/arm64-v8a/libplayer.so`
4. Copy both files into **this** project's `app/src/main/jniLibs/arm64-v8a/`.
5. You don't need the `.aar` file — the Kotlin wrapper in this project links against the .so directly via `System.loadLibrary("player")`.

---

## How to build (you have NO local dev environment)

Everything builds via GitHub Actions. No Android Studio needed.

1. Create a new private GitHub repo (e.g. `animestream`).
2. Unzip this project's contents into the repo root.
3. Drop `libmpv.so` and `libplayer.so` into `app/src/main/jniLibs/arm64-v8a/`.
4. Commit and push.
5. Go to the **Actions** tab on GitHub. The "Build AnimeStream APK" workflow runs automatically on every push.
6. Wait ~10 minutes for the build to finish.
7. Download the `animestream-arm64-apk` artifact at the bottom of the run page.
8. Unzip the artifact — you get `animestream-arm64-debug.apk`.

### If the build fails

- The workflow prints the **first 30 error lines** directly in the Actions log.
- The full `build.log` is uploaded as an artifact named `build-log`.
- Most likely failure: shader fetch script couldn't reach GitHub raw URLs (transient network issue). Re-run the workflow.

---

## How to install the APK on your phone

1. Transfer `animestream-arm64-debug.apk` to your OPPO Reno 11F.
2. In **Settings → Security → Install unknown apps**, allow your file manager to install APKs.
3. Tap the APK in your file manager to install.
4. Open **AnimeStream**.

---

## Using the app

### Sharing from YouTube
1. Open the YouTube app.
2. Find a video. Tap **Share**.
3. Select **AnimeStream** from the share sheet.
4. The video loads in AnimeStream at your configured base resolution, then upscales via your selected shader preset.

### Pasting a URL
1. Open AnimeStream.
2. Paste a YouTube URL into the field.
3. Tap **Play**.

### Gestures
- **Double-tap left side** → seek −10s
- **Double-tap right side** → seek +10s
- **Vertical drag left half** → brightness (high sensitivity, configurable)
- **Vertical drag right half** → volume (low sensitivity, configurable)
- **Drag the scrubber** → seek to any position

### Settings
- **YouTube base resolution** — 144p / 240p / 360p / 480p (default) / 720p / 1080p
- **Shader preset** — 11 presets: None / Anime4K A/B/C/B+Denoise / FSRCNNX 8/16 / ArtCNN / RAVU Lite r3/r4 / KrigBilateral
- **Hardware decoding** — toggle `mediacodec-copy` on/off
- **GPU renderer** — `vo=gpu` vs `vo=gpu-next`
- **Stress Bar benchmark** — 10-second on-device FPS + frame-drop sampler, recommends a preset for your Mali-G610
- **Brightness sensitivity** — 0.5x to 5x
- **Volume sensitivity** — 0.2x to 2x

### Resume playback
When you reopen a video you previously watched, AnimeStream offers to continue from your last position.

---

## Realistic performance expectations (Mali-G610 MC4, 480p → 1080p)

| Preset | Expected FPS | Status |
|---|---|---|
| None (spline36) | 60 | ✓ |
| Anime4K Mode A | 55–60 | ✓ |
| Anime4K Mode B | 40–50 | ⚠ borderline |
| Anime4K Mode C | 25–35 | ✗ drops frames |
| Anime4K Mode B + Denoise | 35–45 | ⚠ borderline |
| FSRCNNX x2 8-0-4-1 | 50–58 | ✓ |
| FSRCNNX x2 16-0-4-1 | 30–40 | ✗ |
| ArtCNN C4F32 | 45–55 | ✓ |
| RAVU Lite r4 | 58–60 | ✓ (fastest quality) |
| RAVU Lite r3 | 60 | ✓ |
| KrigBilateral | 58–60 | ✓ |

**Default preset:** RAVU Lite r4 (best balance for first launch). Run the Stress Bar benchmark after install to confirm what your device can handle.

---

## Architecture

```
User shares YouTube URL
       │
       ▼
MainActivity (intent-filter) ──► PlayerViewModel
       │                              │
       ▼                              ▼
HomeScreen ◄── navigation ──► PlayerScreen ◄──► SettingsScreen
                                  │
                                  ▼
                          AnimeStreamPlayer (wrapper)
                                  │
                                  ▼
                          BaseMPVView (SurfaceView)
                                  │
                                  ▼
                          MPVLib.kt ──► JNI ──► libplayer.so ──► libmpv.so
                                                              │
                                                              ▼
                                                       Anime4K / FSRCNNX /
                                                       ArtCNN / RAVU shaders
                                                              │
                                                              ▼
                                                       Mali-G610 MC4 GPU
```

YouTube stream resolution runs in parallel via NewPipeExtractor (no YouTube API key needed). The resolved video-only and audio-only URLs are passed to libmpv, which muxes them internally via `audio-file` option.

---

## Project structure

```
app/
├── build.gradle.kts                  # Module build config (Kotlin 2.0.21, Compose BOM 2024.10.01)
├── proguard-rules.pro                # Keep mpv + NewPipe classes
├── libs/                             # (optional) libmpv.aar goes here
└── src/main/
    ├── AndroidManifest.xml           # Share intent + permissions
    ├── jniLibs/arm64-v8a/            # libmpv.so + libplayer.so go here (USER PROVIDES)
    ├── assets/shaders/               # Populated by fetch_shaders.sh
    └── java/com/animestream/player/
        ├── MainActivity.kt           # Navigation host + share intent handling
        ├── AnimeStreamApp.kt         # Application class
        ├── ui/
        │   ├── HomeScreen.kt         # URL paste + share hint
        │   ├── PlayerScreen.kt       # Player UI + gestures + scrubber
        │   ├── SettingsScreen.kt     # All 8 setting sections
        │   ├── theme/                # Color.kt, Type.kt, Theme.kt
        │   └── components/           # PlaybackScrubber, StressBarDialog, ShaderPresetPickerSheet
        ├── data/
        │   ├── SettingsRepository.kt # DataStore-backed settings
        │   └── ResumePositions.kt    # Room DB for resume positions
        ├── player/
        │   ├── MPVLib.kt             # JNI wrapper (adapted from mpv-android MIT)
        │   ├── BaseMPVView.kt        # SurfaceView for libmpv output
        │   ├── AnimeStreamPlayer.kt  # High-level player wrapper
        │   ├── ShaderPresets.kt      # All 11 presets
        │   └── StressBenchmark.kt    # 10s FPS+drop sampler
        ├── youtube/
        │   └── YouTubeResolver.kt    # NewPipeExtractor v0.24.3 wrapper
        └── viewmodel/
            └── PlayerViewModel.kt    # Glues YouTube + MPV + settings + UI state
```

---

## Dependencies (pinned)

- Kotlin 2.0.21
- AGP 8.7.0
- KSP 2.0.21-1.0.28
- Compose BOM 2024.10.01
- Material3 1.3.1
- Room 2.6.1
- DataStore 1.1.1
- Coroutines 1.8.1
- Navigation Compose 2.8.3
- NewPipeExtractor v0.24.3 (JitPack)

---

## Troubleshooting

**"libmpv native library not loaded"** — You didn't drop `libmpv.so` and `libplayer.so` into `app/src/main/jniLibs/arm64-v8a/`. See "How to obtain the libmpv AAR" above.

**YouTube extraction fails** — YouTube rotates its cipher. NewPipeExtractor v0.24.3 should handle current ciphers. If it stops working, check the NewPipeExtractor repo for a newer release tag.

**Shaders don't apply** — Run `fetch_shaders.sh` locally to populate `app/src/main/assets/shaders/`, commit them, and push. Or rely on the GitHub Actions workflow which calls the script automatically.

**Build fails with "Unresolved reference: MPVLib"** — You changed the package name in `MPVLib.kt`. Don't. The JNI symbol names in `libplayer.so` are package-bound (`is.xyz.mpv.MPVLib`). If you need to rename, also rebuild `libplayer.so` from source.

**App crashes on launch** — Open logcat. Look for `UnsatisfiedLinkError` — this means `libplayer.so` symbols don't match `MPVLib.kt`. Use Method 2 (build from source) for guaranteed-matched symbols.
