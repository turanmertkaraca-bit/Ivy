package com.animestream.player.player

import android.util.Log
import java.io.File

/**
 * Minimal Kotlin wrapper around libmpv JNI surface.
 *
 * Based on is.xyz.mpv.MPVLib from mpv-android (MIT).
 * The user provides libplayer.so (JNI bridge) and libmpv.so (the engine)
 * in app/src/main/jniLibs/arm64-v8a/. If either is missing, the loadLibrary
 * call throws UnsatisfiedLinkError — AnimeStreamPlayer.init() catches it
 * and surfaces a friendly dialog rather than crashing.
 *
 * Symbol names must match the JNI registration in mpv-android's
 * app/src/main/c/mpv_jni.c — DO NOT rename methods.
 */
object MPVLib {

    private const val TAG = "MPVLib"
    private var nativeLoaded = false

    val isAvailable: Boolean get() = nativeLoaded

    init {
        try {
            System.loadLibrary("player")
            nativeLoaded = true
            Log.i(TAG, "libplayer.so loaded")
        } catch (e: UnsatisfiedLinkError) {
            nativeLoaded = false
            Log.e(TAG, "Failed to load libplayer.so: " + e.message)
        } catch (e: SecurityException) {
            nativeLoaded = false
            Log.e(TAG, "SecurityException loading libplayer.so: " + e.message)
        }
    }

    // ----- Lifecycle -----

    fun create(context: android.content.Context) {
        if (!nativeLoaded) return
        nativeCreate(context)
    }

    fun init(options: Array<String>) {
        if (!nativeLoaded) return
        nativeInit(options)
    }

    fun destroy() {
        if (!nativeLoaded) return
        nativeDestroy()
    }

    fun attachSurface(surface: android.view.Surface) {
        if (!nativeLoaded) return
        nativeAttachSurface(surface)
    }

    fun detachSurface() {
        if (!nativeLoaded) return
        nativeDetachSurface()
    }

    // ----- Commands -----

    fun command(cmd: String) {
        if (!nativeLoaded) return
        val parts = cmd.split(" ").toTypedArray()
        nativeCommand(parts)
    }

    fun commandAsync(cmd: String, id: Int) {
        if (!nativeLoaded) return
        val parts = cmd.split(" ").toTypedArray()
        nativeCommandAsync(parts, id)
    }

    // ----- Property getters -----

    fun getPropertyString(name: String): String? {
        if (!nativeLoaded) return null
        return nativeGetPropertyString(name)
    }

    fun getPropertyInt(name: String): Int? {
        if (!nativeLoaded) return null
        val v = nativeGetPropertyInt(name)
        return if (v == 0L && getPropertyString(name) == null) null else v.toInt()
    }

    fun getPropertyDouble(name: String): Double? {
        if (!nativeLoaded) return null
        return nativeGetPropertyDouble(name)
    }

    fun getPropertyBoolean(name: String): Boolean? {
        if (!nativeLoaded) return null
        return nativeGetPropertyBoolean(name)
    }

    // ----- Property setters -----

    fun setPropertyString(name: String, value: String) {
        if (!nativeLoaded) return
        nativeSetPropertyString(name, value)
    }

    fun setPropertyInt(name: String, value: Int) {
        if (!nativeLoaded) return
        nativeSetPropertyInt(name, value.toLong())
    }

    fun setPropertyDouble(name: String, value: Double) {
        if (!nativeLoaded) return
        nativeSetPropertyDouble(name, value)
    }

    fun setPropertyBoolean(name: String, value: Boolean) {
        if (!nativeLoaded) return
        nativeSetPropertyBoolean(name, value)
    }

    /** Set an option BEFORE init(). After init() use setProperty*. */
    fun setOptionString(name: String, value: String) {
        if (!nativeLoaded) return
        nativeSetOptionString(name, value)
    }

    // ----- Observers -----

    fun addObserver(observer: PropertyObserver, name: String, format: Int) {
        if (!nativeLoaded) return
        nativeAddObserver(observer, name, format)
    }

    fun removeObserver(observer: PropertyObserver) {
        if (!nativeLoaded) return
        nativeRemoveObserver(observer)
    }

    // Observer format constants (match mpv_format enum)
    const val FORMAT_NONE = 0
    const val FORMAT_STRING = 1
    const val FORMAT_OSD_STRING = 2
    const val FORMAT_FLAG = 3
    const val FORMAT_INT64 = 4
    const val FORMAT_DOUBLE = 5
    const val FORMAT_NODE = 6

    // ----- JNI surface — implemented in libplayer.so -----
    private external fun nativeCreate(context: android.content.Context)
    private external fun nativeInit(options: Array<String>)
    private external fun nativeDestroy()
    private external fun nativeAttachSurface(surface: android.view.Surface)
    private external fun nativeDetachSurface()
    private external fun nativeCommand(cmd: Array<String>)
    private external fun nativeCommandAsync(cmd: Array<String>, id: Int)
    private external fun nativeGetPropertyString(name: String): String?
    private external fun nativeGetPropertyInt(name: String): Long
    private external fun nativeGetPropertyDouble(name: String): Double
    private external fun nativeGetPropertyBoolean(name: String): Boolean
    private external fun nativeSetPropertyString(name: String, value: String)
    private external fun nativeSetPropertyInt(name: String, value: Long)
    private external fun nativeSetPropertyDouble(name: String, value: Double)
    private external fun nativeSetPropertyBoolean(name: String, value: Boolean)
    private external fun nativeSetOptionString(name: String, value: String)
    private external fun nativeAddObserver(observer: PropertyObserver, name: String, format: Int)
    private external fun nativeRemoveObserver(observer: PropertyObserver)
}

fun interface PropertyObserver {
    fun onPropertyChanged(name: String, value: Any?)
}
