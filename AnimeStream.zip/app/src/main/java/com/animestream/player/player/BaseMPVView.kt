package com.animestream.player.player

import android.content.Context
import android.graphics.PixelFormat
import android.util.Log
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout

/**
 * SurfaceView that hosts libmpv's video output.
 *
 * Simplified adaptation of is.xyz.mpv.BaseMPVView from mpv-android (MIT).
 * - Sets up SurfaceHolder callbacks
 * - Calls MPVLib.attachSurface() / detachSurface()
 * - Configures mpv options for Android GPU rendering
 *
 * NOT a Compose component — wrapped via AndroidView in PlayerScreen.
 */
class BaseMPVView @JvmOverloads constructor(
    context: Context,
    attrs: android.util.AttributeSet? = null,
    defStyleAttr: Int = 0
) : SurfaceView(context, attrs, defStyleAttr), SurfaceHolder.Callback {

    private val TAG = "BaseMPVView"
    private var surfaceAttached = false
    private var mpvInitialized = false

    init {
        holder.addCallback(this)
        holder.setFormat(PixelFormat.RGBA_8888)
        // Ensure view is opaque for video rendering perf
        setZOrderOnTop(true)
    }

    fun initPlayer(
        hwdec: Boolean,
        gpuNext: Boolean,
        shaderPresetPaths: List<String>
    ) {
        if (!MPVLib.isAvailable) {
            Log.e(TAG, "libmpv not loaded — cannot init player")
            return
        }
        if (mpvInitialized) return

        MPVLib.create(context)

        // Order matters: vo, gpu-context, hwdec must be set BEFORE init()
        MPVLib.setOptionString("vo", if (gpuNext) "gpu-next" else "gpu")
        MPVLib.setOptionString("gpu-context", "android")
        MPVLib.setOptionString("hwdec", if (hwdec) "mediacodec-copy" else "no")
        MPVLib.setOptionString("hwdec-codecs", "h264,mpeg4,vp8,vp9,av1")
        MPVLib.setOptionString("vd-lavc-threads", "4")
        MPVLib.setOptionString("keepaspect", "yes")
        MPVLib.setOptionString("keepaspect-window", "no")
        MPVLib.setOptionString("force-window", "yes")
        MPVLib.setOptionString("audio-channels", "auto-safe")
        MPVLib.setOptionString("volume-max", "100")
        MPVLib.setOptionString("cache", "yes")
        MPVLib.setOptionString("cache-secs", "30")
        MPVLib.setOptionString("demuxer-max-bytes", "50MiB")
        MPVLib.setOptionString("demuxer-max-back-bytes", "20MiB")

        // Default scaler — used when no shaders are set or "None" preset
        MPVLib.setOptionString("scale", "spline36")
        MPVLib.setOptionString("dscale", "mitchell")
        MPVLib.setOptionString("cscale", "bilinear")

        // Shaders — colon-separated filesystem paths
        if (shaderPresetPaths.isNotEmpty()) {
            val joined = shaderPresetPaths.joinToString(":")
            MPVLib.setOptionString("glsl-shaders", joined)
        }

        // Init with empty options array — all config done via setOptionString
        MPVLib.init(emptyArray())

        mpvInitialized = true
        Log.i(TAG, "mpv initialized: hwdec=" + (if (hwdec) "mediacodec-copy" else "no")
                + " vo=" + (if (gpuNext) "gpu-next" else "gpu")
                + " shaders=" + shaderPresetPaths.size)
    }

    fun destroyPlayer() {
        if (!mpvInitialized) return
        if (surfaceAttached) {
            MPVLib.detachSurface()
            surfaceAttached = false
        }
        MPVLib.destroy()
        mpvInitialized = false
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        if (!mpvInitialized) return
        val surface = holder.surface
        if (surface != null && surface.isValid) {
            MPVLib.attachSurface(surface)
            surfaceAttached = true
            Log.i(TAG, "Surface attached")
        }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        // mpv handles resize internally
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        if (surfaceAttached && mpvInitialized) {
            MPVLib.detachSurface()
            surfaceAttached = false
            Log.i(TAG, "Surface detached")
        }
    }

    fun isMpvInitialized(): Boolean = mpvInitialized
}
