package com.animestream.player.player

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.max

/**
 * Stress Bar benchmark: samples mpv properties every 500ms for 10 seconds
 * (21 samples total — t=0 included), then computes a performance tier.
 *
 * Properties sampled:
 *   - estimated-vf-fps (Double)
 *   - frame-drop-count (Int)
 *   - vo-delayed-frame-count (Int)
 *
 * Scoring (Mali-G610 MC4 calibration, 60Hz reference):
 *   - GREEN  : avg FPS >= 57 (95% of 60), max drops <= 2
 *   - YELLOW : avg FPS >= 51 (85% of 60), max drops <= 15
 *   - RED    : otherwise
 *
 * Recommendations:
 *   - GREEN  → Anime4K Mode A (or stay on current)
 *   - YELLOW → FSRCNNX 8-0-4-1 (balanced neural net)
 *   - RED    → RAVU Lite r4 (fastest quality option)
 */
enum class BenchmarkTier { GREEN, YELLOW, RED }

data class BenchmarkResult(
    val avgFps: Double,
    val maxFrameDrops: Int,
    val maxVoDelayed: Int,
    val samples: Int,
    val tier: BenchmarkTier,
    val recommendedPresetId: String,
    val recommendedPresetName: String
) {
    val summary: String
        get() {
            val t = when (tier) {
                BenchmarkTier.GREEN -> "EXCELLENT"
                BenchmarkTier.YELLOW -> "ACCEPTABLE"
                BenchmarkTier.RED -> "OVERLOADED"
            }
            return "Avg FPS: " + String.format("%.1f", avgFps) + " | Max drops: " + maxFrameDrops + " | " + t
        }
}

class StressBenchmark(private val player: AnimeStreamPlayer) {

    private val TAG = "StressBenchmark"
    private var job: Job? = null
    private val _state = MutableStateFlow<BenchmarkState>(BenchmarkState.Idle)
    val state: StateFlow<BenchmarkState> = _state.asStateFlow()

    sealed class BenchmarkState {
        object Idle : BenchmarkState()
        data class Running(val elapsedMs: Long) : BenchmarkState()
        data class Done(val result: BenchmarkResult) : BenchmarkState()
        data class Failed(val reason: String) : BenchmarkState()
    }

    fun start(scope: CoroutineScope) {
        if (job != null && job?.isActive == true) return
        _state.value = BenchmarkState.Running(0L)

        job = scope.launch(Dispatchers.Default) {
            val samplesFps = mutableListOf<Double>()
            val samplesDrops = mutableListOf<Int>()
            val samplesDelayed = mutableListOf<Int>()
            val startMs = System.currentTimeMillis()
            val durationMs = 10_000L
            val intervalMs = 500L

            try {
                while (System.currentTimeMillis() - startMs < durationMs) {
                    val fps = player.let {
                        // Use raw MPVLib to bypass wrapper null guards
                        MPVLib.getPropertyDouble("estimated-vf-fps") ?: 0.0
                    }
                    val drops = MPVLib.getPropertyInt("frame-drop-count") ?: 0
                    val delayed = MPVLib.getPropertyInt("vo-delayed-frame-count") ?: 0

                    samplesFps.add(fps)
                    samplesDrops.add(drops)
                    samplesDelayed.add(delayed)

                    val elapsed = System.currentTimeMillis() - startMs
                    _state.value = BenchmarkState.Running(elapsed)
                    delay(intervalMs)
                }

                if (samplesFps.isEmpty()) {
                    _state.value = BenchmarkState.Failed("No samples collected")
                    return@launch
                }

                val avgFps = samplesFps.sum() / samplesFps.size
                val maxDrops = samplesDrops.maxOrNull() ?: 0
                val maxDelayed = samplesDelayed.maxOrNull() ?: 0

                // Frame drops counter is cumulative — convert to max delta from sample 0
                val baselineDrops = samplesDrops.firstOrNull() ?: 0
                val realMaxDrops = max(0, maxDrops - baselineDrops)

                val tier = when {
                    avgFps >= 57.0 && realMaxDrops <= 2 -> BenchmarkTier.GREEN
                    avgFps >= 51.0 && realMaxDrops <= 15 -> BenchmarkTier.YELLOW
                    else -> BenchmarkTier.RED
                }

                val recommended = when (tier) {
                    BenchmarkTier.GREEN -> "anime4k_a" to "Anime4K Mode A (lightest)"
                    BenchmarkTier.YELLOW -> "fsrcnnx_8" to "FSRCNNX x2 8-0-4-1"
                    BenchmarkTier.RED -> "ravu_lite_r4" to "RAVU Lite r4"
                }

                val result = BenchmarkResult(
                    avgFps = avgFps,
                    maxFrameDrops = realMaxDrops,
                    maxVoDelayed = maxDelayed,
                    samples = samplesFps.size,
                    tier = tier,
                    recommendedPresetId = recommended.first,
                    recommendedPresetName = recommended.second
                )

                Log.i(TAG, "Benchmark done: $result")
                _state.value = BenchmarkState.Done(result)

            } catch (e: Exception) {
                Log.e(TAG, "Benchmark failed: " + e.message)
                _state.value = BenchmarkState.Failed(e.message ?: "unknown")
            }
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        _state.value = BenchmarkState.Idle
    }
}
