package com.animestream.player.player

import android.content.Context
import android.util.Log
import com.animestream.player.data.AppSettings
import java.io.File

/**
 * High-level wrapper that owns a BaseMPVView instance and translates
 * AppSettings + UI events into mpv commands and property writes.
 *
 * Lifecycle:
 *   1. observe(context) — call once on view creation
 *   2. init(settings, shaderDir) — call once before play
 *   3. play(videoUrl, audioUrl, title) — load + play
 *   4. switchPreset(preset) — runtime shader swap
 *   5. destroy() — on view disposal
 */
class AnimeStreamPlayer(private val context: Context) : PropertyObserver {

    private val TAG = "AnimeStreamPlayer"
    private var view: BaseMPVView? = null
    private var initialized = false
    private var observers = mutableSetOf<PropertyObserver>()
    private var currentVideoPath: String? = null

    val isAvailable: Boolean get() = MPVLib.isAvailable

    fun bind(view: BaseMPVView) {
        this.view = view
    }

    fun unbind() {
        this.view = null
    }

    fun init(settings: AppSettings, shaderDir: File) {
        if (!isAvailable) {
            Log.e(TAG, "libmpv not available — init skipped")
            return
        }
        val preset = ShaderPresets.byId(settings.shaderPreset)
        val paths = ShaderPresets.pathsFor(preset, shaderDir)

        view?.initPlayer(
            hwdec = settings.hwDecoding,
            gpuNext = settings.gpuNext,
            shaderPresetPaths = paths
        )

        // Observe properties needed by UI
        MPVLib.addObserver(this, "time-pos", MPVLib.FORMAT_DOUBLE)
        MPVLib.addObserver(this, "duration", MPVLib.FORMAT_DOUBLE)
        MPVLib.addObserver(this, "pause", MPVLib.FORMAT_FLAG)
        MPVLib.addObserver(this, "frame-drop-count", MPVLib.FORMAT_INT64)
        MPVLib.addObserver(this, "estimated-vf-fps", MPVLib.FORMAT_DOUBLE)
        MPVLib.addObserver(this, "vo-delayed-frame-count", MPVLib.FORMAT_INT64)
        MPVLib.addObserver(this, "eof-reached", MPVLib.FORMAT_FLAG)
        MPVLib.addObserver(this, "media-title", MPVLib.FORMAT_STRING)

        initialized = true
    }

    fun play(videoUrl: String, audioUrl: String?, title: String? = null) {
        if (!initialized) {
            Log.w(TAG, "play() called before init() — ignoring")
            return
        }
        currentVideoPath = videoUrl
        // Audio-file MUST be set BEFORE loadfile so mpv muxes them internally
        if (audioUrl != null) {
            MPVLib.setOptionString("audio-file", audioUrl)
        }
        MPVLib.command("loadfile \"$videoUrl\"")
        if (title != null) {
            MPVLib.setPropertyString("force-media-title", title)
        }
        MPVLib.setPropertyBoolean("pause", false)
    }

    fun pause() = MPVLib.setPropertyBoolean("pause", true)
    fun resume() = MPVLib.setPropertyBoolean("pause", false)
    fun togglePause() {
        val p = MPVLib.getPropertyBoolean("pause") ?: return
        MPVLib.setPropertyBoolean("pause", !p)
    }

    fun seekTo(seconds: Double) = MPVLib.setPropertyDouble("time-pos", seconds)
    fun seekBy(delta: Double) = MPVLib.command("seek $delta relative")
    fun setVolume(v: Int) = MPVLib.setPropertyInt("volume", v.coerceIn(0, 100))

    fun getCurrentPosition(): Double = MPVLib.getPropertyDouble("time-pos") ?: 0.0
    fun getDuration(): Double = MPVLib.getPropertyDouble("duration") ?: 0.0
    fun isPaused(): Boolean = MPVLib.getPropertyBoolean("pause") ?: true

    fun switchPreset(preset: ShaderPreset, shaderDir: File) {
        if (!initialized) return
        // Clear all existing shaders by setting empty
        MPVLib.setPropertyString("glsl-shaders-cl", "")
        if (preset.isNone) {
            Log.i(TAG, "Switched to None preset (spline36 only)")
            return
        }
        val paths = ShaderPresets.pathsFor(preset, shaderDir)
        // Use glsl-shaders-cl with "+" prefix to add shaders at runtime
        val joined = "+" + paths.joinToString(":")
        MPVLib.setPropertyString("glsl-shaders-cl", joined)
        Log.i(TAG, "Switched preset to ${preset.displayName} (${paths.size} files)")
    }

    fun destroy() {
        observers.clear()
        view?.destroyPlayer()
        view = null
        initialized = false
    }

    fun addObserver(o: PropertyObserver) { observers.add(o) }
    fun removeObserver(o: PropertyObserver) { observers.remove(o) }

    override fun onPropertyChanged(name: String, value: Any?) {
        // Forward to all UI observers
        val iter = observers.iterator()
        while (iter.hasNext()) {
            val o = iter.next()
            try {
                o.onPropertyChanged(name, value)
            } catch (e: Exception) {
                Log.w(TAG, "Observer threw on $name: " + e.message)
            }
        }
    }
}
