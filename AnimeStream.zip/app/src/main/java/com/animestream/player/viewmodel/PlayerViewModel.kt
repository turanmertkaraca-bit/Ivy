package com.animestream.player.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.animestream.player.data.AppSettings
import com.animestream.player.data.AnimeStreamDatabase
import com.animestream.player.data.ResumePosition
import com.animestream.player.data.SettingsRepository
import com.animestream.player.player.AnimeStreamPlayer
import com.animestream.player.player.BenchmarkResult
import com.animestream.player.player.ShaderPresets
import com.animestream.player.player.StressBenchmark
import com.animestream.player.youtube.ResolvedStream
import com.animestream.player.youtube.YouTubeResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed class PlayerUiState {
    object Idle : PlayerUiState()
    object Loading : PlayerUiState()
    data class Ready(val stream: ResolvedStream) : PlayerUiState()
    data class Error(val message: String) : PlayerUiState()
}

class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val TAG = "PlayerViewModel"
    private val settingsRepo = SettingsRepository(application)
    private val db = AnimeStreamDatabase.get(application)
    private val resolver = YouTubeResolver()

    val settings: StateFlow<AppSettings> = settingsRepo.settings.stateIn(
        viewModelScope, SharingStarted.Eagerly, AppSettings()
    )

    val player = AnimeStreamPlayer(application)
    val benchmark = StressBenchmark(player)

    private val _uiState = MutableStateFlow<PlayerUiState>(PlayerUiState.Idle)
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private val _position = MutableStateFlow(0.0)
    val position: StateFlow<Double> = _position.asStateFlow()

    private val _duration = MutableStateFlow(0.0)
    val duration: StateFlow<Double> = _duration.asStateFlow()

    private val _paused = MutableStateFlow(true)
    val paused: StateFlow<Boolean> = _paused.asStateFlow()

    private val _fps = MutableStateFlow(0.0)
    val fps: StateFlow<Double> = _fps.asStateFlow()

    private val _currentTitle = MutableStateFlow("")
    val currentTitle: StateFlow<String> = _currentTitle.asStateFlow()

    private var shaderDir: File = ShaderPresets.ensureExtracted(application)

    init {
        // Forward mpv property changes to UI flows
        player.addObserver { name, value ->
            when (name) {
                "time-pos" -> {
                    val v = (value as? Double) ?: 0.0
                    _position.value = v
                }
                "duration" -> {
                    val v = (value as? Double) ?: 0.0
                    _duration.value = v
                }
                "pause" -> {
                    _paused.value = value as? Boolean ?: true
                }
                "estimated-vf-fps" -> {
                    val v = (value as? Double) ?: 0.0
                    _fps.value = v
                }
                "media-title" -> {
                    _currentTitle.value = value as? String ?: ""
                }
                "eof-reached" -> {
                    if (value == true) {
                        _paused.value = true
                    }
                }
            }
        }
    }

    fun loadUrl(url: String) {
        viewModelScope.launch {
            _uiState.value = PlayerUiState.Loading
            try {
                val s = settings.value
                val resolved = withContext(Dispatchers.IO) {
                    resolver.resolve(url, s.baseResolution)
                }
                Log.i(TAG, "Resolved: " + resolved.title + " — video=" + (resolved.videoUrl.take(60)) + "...")
                _uiState.value = PlayerUiState.Ready(resolved)

                // Save resume record
                val videoId = extractVideoId(url) ?: url.hashCode().toString()
                db.resumeDao().upsert(
                    ResumePosition(
                        videoId = videoId,
                        positionSeconds = 0L,
                        durationSeconds = resolved.durationSeconds,
                        title = resolved.title,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            } catch (e: Exception) {
                Log.e(TAG, "Resolution failed: " + e.message, e)
                _uiState.value = PlayerUiState.Error("Failed to extract stream: " + (e.message ?: "unknown"))
            }
        }
    }

    fun initPlayer() {
        val s = settings.value
        player.init(s, shaderDir)
    }

    fun playStream(stream: ResolvedStream, startFrom: Double = 0.0) {
        player.play(stream.videoUrl, stream.audioUrl, stream.title)
        if (startFrom > 0) {
            player.seekTo(startFrom)
        }
    }

    fun seekBy(delta: Double) = player.seekBy(delta)
    fun seekTo(seconds: Double) = player.seekTo(seconds)
    fun togglePause() = player.togglePause()
    fun setVolume(v: Int) = player.setVolume(v)

    fun switchPreset(presetId: String) {
        viewModelScope.launch {
            settingsRepo.setShaderPreset(presetId)
            val preset = ShaderPresets.byId(presetId)
            player.switchPreset(preset, shaderDir)
        }
    }

    fun runBenchmark() = benchmark.start(viewModelScope)

    fun saveResume(videoId: String, position: Double, duration: Double, title: String) {
        viewModelScope.launch {
            if (position < 5.0 || position >= duration - 5.0) return@launch
            db.resumeDao().upsert(
                ResumePosition(
                    videoId = videoId,
                    positionSeconds = position.toLong(),
                    durationSeconds = duration.toLong(),
                    title = title,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    fun getResumePosition(videoId: String) = db.resumeDao().get(videoId)

    fun updateSettings(transform: suspend (SettingsRepository) -> Unit) {
        viewModelScope.launch { transform(settingsRepo) }
    }

    private fun extractVideoId(url: String): String? {
        val patterns = listOf(
            Regex("v=([a-zA-Z0-9_-]{11})"),
            Regex("youtu\\.be/([a-zA-Z0-9_-]{11})"),
            Regex("/shorts/([a-zA-Z0-9_-]{11})"),
            Regex("/embed/([a-zA-Z0-9_-]{11})")
        )
        for (p in patterns) {
            val m = p.find(url)
            if (m != null) return m.groupValues[1]
        }
        return null
    }

    override fun onCleared() {
        player.destroy()
        super.onCleared()
    }
}
