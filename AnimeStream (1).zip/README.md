# AnimeStream

A custom Android YouTube streaming app that fetches low-resolution video from YouTube and upscales it on-device using **libmpv's** shader pipeline. Real Anime4K, FSRCNNX, ArtCNN, and RAVU shaders run on your Mali-G610 GPU — same upscaling quality as mpv-android, in a cleaner app shell.

**Target device:** OPPO Reno 11F 5G (Dimensity 7050, Mali-G610 MC4, arm64-v8a, Android 13)
**Personal use only** — not for Play Store.

---

## ✅ Everything is automatic

The GitHub Actions workflow handles **everything** for you:

1. Extracts the project zip (so you can upload a single zip via the web UI)
2. Commits the extracted files back to your repo
3. **Downloads the latest mpv-android arm64-v8a release APK** and extracts:
   - `libmpv.so` — the mpv engine + ffmpeg + libplacebo (6.6 MB)
   - `libplayer.so` — the JNI bridge (22 KB)
   - `libavcodec.so`, `libavformat.so`, `libavfilter.so`, `libavutil.so` — ffmpeg
   - `libswresample.so`, `libswscale.so`, `libavdevice.so` — more ffmpeg
   - `libc++_shared.so` — C++ runtime
4. Fetches all Anime4K / FSRCNNX / ArtCNN / RAVU / KrigBilateral shader files
5. Builds the APK
6. Uploads it as a downloadable artifact

You don't need a local dev environment, you don't need to manually fetch .so files, you don't need to mess with NDK.

---

## Quick start (3 file uploads, ~10 minutes)

1. Create a new private GitHub repo (e.g. `animestream`). Leave it empty — no README, no .gitignore.
2. **Add file → Create new file** → name it `.github/workflows/build.yml` → paste the contents of `build.yml` → commit
3. **Add file → Upload files** → drag `AnimeStream.zip` in → commit
4. Go to the **Actions** tab → watch the workflow run → wait ~10 minutes
5. Download the `animestream-arm64-apk` artifact → unzip → install the APK on your phone

Full step-by-step guide: see `HOW_TO_BUILD.md` in the download folder.

---

## How the libmpv auto-download works

The workflow step "Download libmpv native libraries":

1. Queries `https://github.com/mpv-android/mpv-android/releases.atom` (no auth needed) to find the latest release tag
2. Tries these APK filename patterns (mpv-android has changed naming over the years):
   - `app-default-arm64-v8a-release.apk` (current naming)
   - `mpv-android-arm64-v8a.apk` (older naming)
   - `app-arm64-v8a-release.apk`
   - `app-default-arm64-v8a-debug.apk`
3. Falls back to `app-default-universal-debug.apk` if none of the arm64-v8a patterns match
4. Extracts all `lib/arm64-v8a/*.so` files from the APK into `app/src/main/jniLibs/arm64-v8a/`
5. Verifies `libmpv.so` and `libplayer.so` are present — fails the build if not

The workflow skips this step if `.so` files are already present in the repo (so you can override with custom builds if you ever need to).

---

## If you want to provide your own .so files (optional)

If the auto-download doesn't work for some reason, or you want to use a specific mpv-android version:

### Method 1: Extract from a specific mpv-android APK

1. Go to https://github.com/mpv-android/mpv-android/releases
2. Download the `app-default-arm64-v8a-release.apk` from your preferred release
3. Unzip it (APKs are ZIPs):
   ```
   unzip app-default-arm64-v8a-release.apk -d mpv-extracted
   ```
4. Copy all .so files into the project:
   ```
   cp mpv-extracted/lib/arm64-v8a/*.so app/src/main/jniLibs/arm64-v8a/
   ```
5. Commit and push. The workflow detects the files are present and skips the download step.

### Method 2: Build libmpv from source

For advanced users who want to build mpv from a specific commit:

1. Clone mpv-android on a Linux machine (or WSL2):
   ```
   git clone https://github.com/mpv-android/mpv-android.git
   cd mpv-android/buildscripts
   ./buildall.sh
   ```
2. Copy `app/src/main/jniLibs/arm64-v8a/*.so` from the built tree into this project.
3. Commit and push.

---

## How to install the APK on your phone

1. Transfer `animestream-arm64-debug.apk` to your OPPO Reno 11F.
2. In **Settings → Security → Install unknown apps**, allow your file manager to install APKs.
3. Tap the APK in your file manager to install.
4. Open **AnimeStream**.

---

## Using the app

### Sharing from YouTube
1. Open the YouTube app.
2. Find a video. Tap **Share**.
3. Select **AnimeStream** from the share sheet.
4. The video loads in AnimeStream at your configured base resolution, then upscales via your selected shader preset.

### Pasting a URL
1. Open AnimeStream.
2. Paste a YouTube URL into the field.
3. Tap **Play**.

### Gestures
- **Double-tap left side** → seek −10s
- **Double-tap right side** → seek +10s
- **Vertical drag left half** → brightness (high sensitivity, configurable)
- **Vertical drag right half** → volume (low sensitivity, configurable)
- **Drag the scrubber** → seek to any position

### Settings
- **YouTube base resolution** — 144p / 240p / 360p / 480p (default) / 720p / 1080p
- **Shader preset** — 11 presets: None / Anime4K A/B/C/B+Denoise / FSRCNNX 8/16 / ArtCNN / RAVU Lite r3/r4 / KrigBilateral
- **Hardware decoding** — toggle `mediacodec-copy` on/off
- **GPU renderer** — `vo=gpu` vs `vo=gpu-next`
- **Stress Bar benchmark** — 10-second on-device FPS + frame-drop sampler, recommends a preset for your Mali-G610
- **Brightness sensitivity** — 0.5x to 5x
- **Volume sensitivity** — 0.2x to 2x

### Resume playback
When you reopen a video you previously watched, AnimeStream offers to continue from your last position.

---

## Realistic performance expectations (Mali-G610 MC4, 480p → 1080p)

| Preset | Expected FPS | Status |
|---|---|---|
| None (spline36) | 60 | ✓ |
| Anime4K Mode A | 55–60 | ✓ |
| Anime4K Mode B | 40–50 | ⚠ borderline |
| Anime4K Mode C | 25–35 | ✗ drops frames |
| Anime4K Mode B + Denoise | 35–45 | ⚠ borderline |
| FSRCNNX x2 8-0-4-1 | 50–58 | ✓ |
| FSRCNNX x2 16-0-4-1 | 30–40 | ✗ |
| ArtCNN C4F32 | 45–55 | ✓ |
| RAVU Lite r4 | 58–60 | ✓ (fastest quality) |
| RAVU Lite r3 | 60 | ✓ |
| KrigBilateral | 58–60 | ✓ |

**Default preset:** RAVU Lite r4 (best balance for first launch). Run the Stress Bar benchmark after install to confirm what your device can handle.

---

## Architecture

```
User shares YouTube URL
       │
       ▼
MainActivity (intent-filter) ──► PlayerViewModel
       │                              │
       ▼                              ▼
HomeScreen ◄── navigation ──► PlayerScreen ◄──► SettingsScreen
                                  │
                                  ▼
                          AnimeStreamPlayer (wrapper)
                                  │
                                  ▼
                          BaseMPVView (SurfaceView)
                                  │
                                  ▼
                          MPVLib.kt ──► JNI ──► libplayer.so ──► libmpv.so
                                                              │
                                                              ▼
                                                       Anime4K / FSRCNNX /
                                                       ArtCNN / RAVU shaders
                                                              │
                                                              ▼
                                                       Mali-G610 MC4 GPU
```

YouTube stream resolution runs in parallel via NewPipeExtractor (no YouTube API key needed). The resolved video-only and audio-only URLs are passed to libmpv, which muxes them internally via `audio-file` option.

---

## Project structure

```
app/
├── build.gradle.kts                  # Module build config (Kotlin 2.0.21, Compose BOM 2024.10.01)
├── proguard-rules.pro                # Keep mpv + NewPipe classes
├── libs/                             # (optional) libmpv.aar goes here
└── src/main/
    ├── AndroidManifest.xml           # Share intent + permissions
    ├── jniLibs/arm64-v8a/            # libmpv.so + libplayer.so go here (USER PROVIDES)
    ├── assets/shaders/               # Populated by fetch_shaders.sh
    └── java/com/animestream/player/
        ├── MainActivity.kt           # Navigation host + share intent handling
        ├── AnimeStreamApp.kt         # Application class
        ├── ui/
        │   ├── HomeScreen.kt         # URL paste + share hint
        │   ├── PlayerScreen.kt       # Player UI + gestures + scrubber
        │   ├── SettingsScreen.kt     # All 8 setting sections
        │   ├── theme/                # Color.kt, Type.kt, Theme.kt
        │   └── components/           # PlaybackScrubber, StressBarDialog, ShaderPresetPickerSheet
        ├── data/
        │   ├── SettingsRepository.kt # DataStore-backed settings
        │   └── ResumePositions.kt    # Room DB for resume positions
        ├── player/
        │   ├── MPVLib.kt             # JNI wrapper (adapted from mpv-android MIT)
        │   ├── BaseMPVView.kt        # SurfaceView for libmpv output
        │   ├── AnimeStreamPlayer.kt  # High-level player wrapper
        │   ├── ShaderPresets.kt      # All 11 presets
        │   └── StressBenchmark.kt    # 10s FPS+drop sampler
        ├── youtube/
        │   └── YouTubeResolver.kt    # NewPipeExtractor v0.24.3 wrapper
        └── viewmodel/
            └── PlayerViewModel.kt    # Glues YouTube + MPV + settings + UI state
```

---

## Dependencies (pinned)

- Kotlin 2.0.21
- AGP 8.7.0
- KSP 2.0.21-1.0.28
- Compose BOM 2024.10.01
- Material3 1.3.1
- Room 2.6.1
- DataStore 1.1.1
- Coroutines 1.8.1
- Navigation Compose 2.8.3
- NewPipeExtractor v0.24.3 (JitPack)

---

## Troubleshooting

**Workflow step "Download libmpv native libraries" failed** — The mpv-android release naming changed. Check the latest release at https://github.com/mpv-android/mpv-android/releases and add the new filename pattern to the `for pattern in ...` loop in `.github/workflows/build.yml`.

**"libmpv native library not loaded" toast in app** — The auto-download step succeeded but the .so files weren't packaged into the APK. Check the workflow log for the "Final .so inventory" section — it should list `libmpv.so` and `libplayer.so`. If they're missing, the download silently failed; re-run the workflow.

**YouTube extraction fails** — YouTube rotates its cipher. NewPipeExtractor v0.24.3 should handle current ciphers. If it stops working, check the NewPipeExtractor repo for a newer release tag and bump the version in `gradle/libs.versions.toml`.

**Shaders don't apply** — Run `fetch_shaders.sh` locally to populate `app/src/main/assets/shaders/`, commit them, and push. Or rely on the GitHub Actions workflow which calls the script automatically.

**Build fails with "Unresolved reference: MPVLib"** — You changed the package name in `MPVLib.kt`. Don't. The JNI symbol names in `libplayer.so` are package-bound (`is.xyz.mpv.MPVLib`). The Kotlin file MUST live at `app/src/main/java/is/xyz/mpv/MPVLib.kt` with `package is.xyz.mpv`.

**App crashes on launch with `UnsatisfiedLinkError`** — `libplayer.so` symbols don't match `MPVLib.kt`. This happens if mpv-android has updated their JNI surface and the auto-downloaded `.so` is newer than this project's `MPVLib.kt`. Fix: copy the latest `MPVLib.kt` from https://github.com/mpv-android/mpv-android/blob/master/app/src/main/java/is/xyz/mpv/MPVLib.kt and replace the one in this project.
