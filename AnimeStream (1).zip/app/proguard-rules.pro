# Keep mpv-android wrapper classes (JNI bridge)
-keep class is.xyz.mpv.** { *; }

# Keep NewPipeExtractor classes (uses reflection)
-keep class org.schabi.newpipe.** { *; }
-keep class org.schabi.newpipe.extractor.** { *; }
-dontwarn org.schabi.newpipe.**

# Keep all native method declarations
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep Room generated classes
-keep class * extends androidx.room.RoomDatabase { *; }

# Kotlin metadata
-keepattributes *Annotation*, InnerClasses, Signature, Exceptions
-dontwarn kotlinx.coroutines.**
-dontwarn org.jsoup.**
-dontwarn org.nanohttpd.**

# OkHttp (transitive from NewPipeExtractor)
-dontwarn okhttp3.**
-dontwarn okio.**
