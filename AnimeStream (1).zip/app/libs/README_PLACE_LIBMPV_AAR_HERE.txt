# Place libmpv.aar here (optional — if you have it).
# The build also works without the AAR if you have the .so files in jniLibs.
# See README.md for details.
