package com.animestream.player.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.animestream.player.player.BenchmarkResult
import com.animestream.player.player.BenchmarkTier
import com.animestream.player.ui.theme.Aurora
import com.animestream.player.ui.theme.Coral
import com.animestream.player.ui.theme.Marigold
import com.animestream.player.ui.theme.Neon

@Composable
fun StressBarDialog(
    running: Boolean,
    progress: Float,
    result: BenchmarkResult?,
    onApplyRecommended: () -> Unit,
    onDismiss: () -> Unit
) {
    if (!running && result == null) return

    AlertDialog(
        onDismissRequest = {
            if (!running) onDismiss()
        },
        title = {
            Text(
                if (running) "Running benchmark…" else "Benchmark complete",
                style = MaterialTheme.typography.headlineSmall
            )
        },
        text = {
            if (running) {
                Column {
                    Text(
                        "Sampling mpv properties every 500ms for 10 seconds. Stay on the player screen — keep the video playing.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(16.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        String.format("%.0f%%", progress * 100),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            } else if (result != null) {
                Column {
                    TierBadge(result.tier)
                    Spacer(Modifier.height(12.dp))
                    MetricRow("Avg FPS", String.format("%.1f", result.avgFps))
                    MetricRow("Max frame drops", result.maxFrameDrops.toString())
                    MetricRow("Max VO delayed", result.maxVoDelayed.toString())
                    MetricRow("Samples", result.samples.toString())
                    Spacer(Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(
                                "Recommended preset",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                result.recommendedPresetName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!running && result != null) {
                TextButton(onClick = onApplyRecommended) {
                    Text("Apply recommended")
                }
            }
        },
        dismissButton = {
            if (!running) {
                TextButton(onClick = onDismiss) {
                    Text("Close")
                }
            }
        }
    )
}

@Composable
private fun TierBadge(tier: BenchmarkTier) {
    val (color, label) = when (tier) {
        BenchmarkTier.GREEN -> Neon to "EXCELLENT — runs comfortably"
        BenchmarkTier.YELLOW -> Marigold to "ACCEPTABLE — may drop frames"
        BenchmarkTier.RED -> Coral to "OVERLOADED — switch to lighter preset"
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.18f))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = color,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun MetricRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}
