package com.animestream.player.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "animestream_settings")

object SettingsKeys {
    val BASE_RESOLUTION = stringPreferencesKey("base_resolution")          // "480p"
    val SHADER_PRESET = stringPreferencesKey("shader_preset")              // preset id
    val HW_DECODING = booleanPreferencesKey("hw_decoding")                 // true=mediacodec
    val GPU_NEXT = booleanPreferencesKey("gpu_next")                       // true=gpu-next
    val BRIGHTNESS_SENS = floatPreferencesKey("brightness_sensitivity")    // 0.5..5.0
    val VOLUME_SENS = floatPreferencesKey("volume_sensitivity")            // 0.2..2.0
}

data class AppSettings(
    val baseResolution: String = "480p",
    val shaderPreset: String = "ravu_lite_r4",
    val hwDecoding: Boolean = true,
    val gpuNext: Boolean = false,
    val brightnessSensitivity: Float = 2.5f,
    val volumeSensitivity: Float = 0.8f
)

class SettingsRepository(private val context: Context) {

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            baseResolution = prefs[SettingsKeys.BASE_RESOLUTION] ?: "480p",
            shaderPreset = prefs[SettingsKeys.SHADER_PRESET] ?: "ravu_lite_r4",
            hwDecoding = prefs[SettingsKeys.HW_DECODING] ?: true,
            gpuNext = prefs[SettingsKeys.GPU_NEXT] ?: false,
            brightnessSensitivity = prefs[SettingsKeys.BRIGHTNESS_SENS] ?: 2.5f,
            volumeSensitivity = prefs[SettingsKeys.VOLUME_SENS] ?: 0.8f
        )
    }

    suspend fun setBaseResolution(value: String) {
        context.dataStore.edit { it[SettingsKeys.BASE_RESOLUTION] = value }
    }

    suspend fun setShaderPreset(value: String) {
        context.dataStore.edit { it[SettingsKeys.SHADER_PRESET] = value }
    }

    suspend fun setHwDecoding(value: Boolean) {
        context.dataStore.edit { it[SettingsKeys.HW_DECODING] = value }
    }

    suspend fun setGpuNext(value: Boolean) {
        context.dataStore.edit { it[SettingsKeys.GPU_NEXT] = value }
    }

    suspend fun setBrightnessSensitivity(value: Float) {
        context.dataStore.edit { it[SettingsKeys.BRIGHTNESS_SENS] = value }
    }

    suspend fun setVolumeSensitivity(value: Float) {
        context.dataStore.edit { it[SettingsKeys.VOLUME_SENS] = value }
    }
}
