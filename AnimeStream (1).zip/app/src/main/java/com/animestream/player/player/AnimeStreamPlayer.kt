package com.animestream.player.player

import `is`.xyz.mpv.BaseMPVView
import `is`.xyz.mpv.MPVLib
import `is`.xyz.mpv.MPVLib.MpvFormat
import android.content.Context
import android.util.Log
import com.animestream.player.data.AppSettings
import java.io.File

/**
 * High-level wrapper that owns a BaseMPVView instance and translates
 * AppSettings + UI events into mpv commands and property writes.
 *
 * Lifecycle:
 *   1. bind(view)             — attach to a BaseMPVView created via AndroidView
 *   2. init(settings, dir)    — configure + start mpv
 *   3. play(video, audio, title)
 *   4. switchPreset(preset)   — runtime shader swap
 *   5. destroy()              — on view disposal
 *
 * Property change events are forwarded to UI observers via [PropertyChangeListener].
 */
class AnimeStreamPlayer(private val context: Context) : MPVLib.EventObserver {

    private val TAG = "AnimeStreamPlayer"
    private var view: BaseMPVView? = null
    private var initialized = false

    private val listeners = mutableListOf<PropertyChangeListener>()

    // Always-safe to call — MPVLib static init loads .so files; if they're missing
    // the first call to MPVLib throws UnsatisfiedLinkError which we catch here.
    val isAvailable: Boolean by lazy {
        try {
            // Force initialization (true as 3rd arg) — triggers static { loadLibrary() }
            Class.forName("is.xyz.mpv.MPVLib", true, this.javaClass.classLoader)
            true
        } catch (e: Throwable) {
            Log.e(TAG, "libmpv unavailable: " + e.message)
            false
        }
    }

    fun bind(view: BaseMPVView) {
        this.view = view
    }

    fun unbind() {
        this.view = null
    }

    fun init(settings: AppSettings, shaderDir: File) {
        if (!isAvailable) {
            Log.e(TAG, "libmpv not available — init skipped")
            return
        }
        if (initialized) return

        val preset = ShaderPresets.byId(settings.shaderPreset)
        val paths = ShaderPresets.pathsFor(preset, shaderDir)

        view?.initPlayer(
            hwdec = settings.hwDecoding,
            gpuNext = settings.gpuNext,
            shaderPresetPaths = paths
        )

        // Register self as observer — mpv will call eventProperty() on changes
        MPVLib.addObserver(this)

        // Observe the properties UI needs
        MPVLib.observeProperty("time-pos", MpvFormat.MPV_FORMAT_DOUBLE)
        MPVLib.observeProperty("duration", MpvFormat.MPV_FORMAT_DOUBLE)
        MPVLib.observeProperty("pause", MpvFormat.MPV_FORMAT_FLAG)
        MPVLib.observeProperty("frame-drop-count", MpvFormat.MPV_FORMAT_INT64)
        MPVLib.observeProperty("estimated-vf-fps", MpvFormat.MPV_FORMAT_DOUBLE)
        MPVLib.observeProperty("vo-delayed-frame-count", MpvFormat.MPV_FORMAT_INT64)
        MPVLib.observeProperty("eof-reached", MpvFormat.MPV_FORMAT_FLAG)
        MPVLib.observeProperty("media-title", MpvFormat.MPV_FORMAT_STRING)

        initialized = true
    }

    fun play(videoUrl: String, audioUrl: String?, title: String? = null) {
        if (!initialized) {
            Log.w(TAG, "play() called before init() — ignoring")
            return
        }
        // audio-file MUST be set BEFORE loadfile so mpv muxes them internally
        if (audioUrl != null) {
            MPVLib.setPropertyString("audio-file", audioUrl)
        }
        // command() takes Array<out String> — split URL into one argument
        MPVLib.command(arrayOf("loadfile", videoUrl))
        if (title != null) {
            MPVLib.setPropertyString("force-media-title", title)
        }
        MPVLib.setPropertyBoolean("pause", false)
    }

    fun pause() = MPVLib.setPropertyBoolean("pause", true)
    fun resume() = MPVLib.setPropertyBoolean("pause", false)

    fun togglePause() {
        val p = MPVLib.getPropertyBoolean("pause") ?: return
        MPVLib.setPropertyBoolean("pause", !p)
    }

    fun seekTo(seconds: Double) = MPVLib.setPropertyDouble("time-pos", seconds)
    fun seekBy(delta: Double) = MPVLib.command(arrayOf("seek", delta.toString(), "relative"))
    fun setVolume(v: Int) = MPVLib.setPropertyInt("volume", v.coerceIn(0, 100))

    fun getCurrentPosition(): Double = MPVLib.getPropertyDouble("time-pos") ?: 0.0
    fun getDuration(): Double = MPVLib.getPropertyDouble("duration") ?: 0.0
    fun isPaused(): Boolean = MPVLib.getPropertyBoolean("pause") ?: true

    fun switchPreset(preset: ShaderPreset, shaderDir: File) {
        if (!initialized) return
        // Clear existing shaders, then add the new ones with "+" prefix
        MPVLib.setPropertyString("glsl-shaders-cl", "")
        if (preset.isNone) {
            Log.i(TAG, "Switched to None preset (spline36 only)")
            return
        }
        val paths = ShaderPresets.pathsFor(preset, shaderDir)
        val joined = "+" + paths.joinToString(":")
        MPVLib.setPropertyString("glsl-shaders-cl", joined)
        Log.i(TAG, "Switched preset to ${preset.displayName} (${paths.size} files)")
    }

    fun destroy() {
        if (!initialized) return
        listeners.clear()
        view?.destroyPlayer()
        view = null
        try {
            MPVLib.removeObserver(this)
        } catch (e: Exception) {
            Log.w(TAG, "removeObserver failed: " + e.message)
        }
        initialized = false
    }

    fun addListener(l: PropertyChangeListener) { listeners.add(l) }
    fun removeListener(l: PropertyChangeListener) { listeners.remove(l) }

    // ---- MPVLib.EventObserver callbacks (called from JNI thread) ----

    override fun eventProperty(property: String, value: Long) {
        val v: Any = value
        forward(property, v)
    }

    override fun eventProperty(property: String, value: Boolean) {
        forward(property, value)
    }

    override fun eventProperty(property: String, value: Double) {
        forward(property, value)
    }

    override fun eventProperty(property: String, value: String) {
        forward(property, value)
    }

    override fun eventProperty(property: String) {
        forward(property, null)
    }

    override fun event(eventId: Int) {
        // mpv events (file-loaded, end-file, etc.) — not currently used
    }

    private fun forward(name: String, value: Any?) {
        val iter = listeners.iterator()
        while (iter.hasNext()) {
            val l = iter.next()
            try {
                l.onPropertyChanged(name, value)
            } catch (e: Exception) {
                Log.w(TAG, "Listener threw on $name: " + e.message)
            }
        }
    }
}

/** UI-facing listener. Value type depends on the property:
 *  - "time-pos" / "duration" / "estimated-vf-fps" → Double
 *  - "pause" / "eof-reached" → Boolean
 *  - "frame-drop-count" / "vo-delayed-frame-count" → Long
 *  - "media-title" → String
 *  - property invalidation → null
 */
fun interface PropertyChangeListener {
    fun onPropertyChanged(name: String, value: Any?)
}
