package com.animestream.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.animestream.player.player.ShaderPresets
import com.animestream.player.ui.components.ShaderPresetPickerSheet
import com.animestream.player.ui.components.StressBarDialog
import com.animestream.player.ui.theme.Aurora
import com.animestream.player.ui.theme.Marigold
import com.animestream.player.ui.theme.Neon
import com.animestream.player.ui.theme.Sakura
import com.animestream.player.viewmodel.PlayerViewModel
import androidx.compose.runtime.LaunchedEffect
import com.animestream.player.player.StressBenchmark

@Composable
fun SettingsScreen(
    viewModel: PlayerViewModel,
    onBack: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    val benchmarkState by viewModel.benchmark.state.collectAsState()

    var showPresetSheet by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Spacer(Modifier.height(8.dp))

            // ---- Video quality section ----
            SectionHeader("Video Quality")
            CardContainer {
                Column {
                    SelectorRow(
                        title = "YouTube base resolution",
                        subtitle = "Lower resolutions save bandwidth. Shaders upscale on-device.",
                        current = settings.baseResolution,
                        options = com.animestream.player.youtube.YouTubeResolver.SUPPORTED_RESOLUTIONS,
                        onSelect = { res ->
                            viewModel.updateSettings { it.setBaseResolution(res) }
                        }
                    )
                    Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                    InfoRow(
                        title = "Target display resolution",
                        subtitle = "Automatic — shaders handle actual scaling (480p→1080p typical)."
                    )
                }
            }

            // ---- Upscaler section ----
            SectionHeader("Upscaler")
            CardContainer {
                val preset = ShaderPresets.byId(settings.shaderPreset)
                ClickableRow(
                    title = "Shader preset",
                    subtitle = preset.displayName + " — " + preset.estimatedPerf,
                    onClick = { showPresetSheet = true }
                )
            }

            // ---- Decoder section ----
            SectionHeader("Decoder")
            CardContainer {
                Column {
                    SwitchRow(
                        title = "Hardware decoding",
                        subtitle = "mediacodec-copy (recommended on Mali-G610)",
                        checked = settings.hwDecoding,
                        onCheckedChange = { v ->
                            viewModel.updateSettings { it.setHwDecoding(v) }
                        }
                    )
                    Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                    SwitchRow(
                        title = "Use vo=gpu-next",
                        subtitle = "Newer renderer. Better HDR, slightly less stable.",
                        checked = settings.gpuNext,
                        onCheckedChange = { v ->
                            viewModel.updateSettings { it.setGpuNext(v) }
                        }
                    )
                }
            }

            // ---- Performance section ----
            SectionHeader("Performance")
            CardContainer {
                ActionRow(
                    icon = Icons.Default.Speed,
                    title = "Run Stress Bar benchmark",
                    subtitle = "10s sample of FPS + frame drops. Recommends a preset.",
                    iconTint = Neon,
                    onClick = { viewModel.runBenchmark() }
                )
            }

            // ---- Gestures section ----
            SectionHeader("Gestures")
            CardContainer {
                Column {
                    SliderRow(
                        title = "Brightness sensitivity",
                        subtitle = String.format("%.1fx — higher = smaller swipe = bigger change", settings.brightnessSensitivity),
                        value = settings.brightnessSensitivity,
                        range = 0.5f..5.0f,
                        onValueChange = { v ->
                            viewModel.updateSettings { it.setBrightnessSensitivity(v) }
                        }
                    )
                    Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                    SliderRow(
                        title = "Volume sensitivity",
                        subtitle = String.format("%.1fx — low to avoid accidental deafening", settings.volumeSensitivity),
                        value = settings.volumeSensitivity,
                        range = 0.2f..2.0f,
                        onValueChange = { v ->
                            viewModel.updateSettings { it.setVolumeSensitivity(v) }
                        }
                    )
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }

    // Bottom sheet for preset picker
    if (showPresetSheet) {
        ShaderPresetPickerSheet(
            presets = ShaderPresets.presets,
            selectedId = settings.shaderPreset,
            onSelect = { preset ->
                viewModel.switchPreset(preset.id)
            },
            onDismiss = { showPresetSheet = false }
        )
    }

    // Benchmark dialog
    val runningState = benchmarkState as? StressBenchmark.BenchmarkState.Running
    val doneState = benchmarkState as? StressBenchmark.BenchmarkState.Done

    if (runningState != null || doneState != null) {
        val progress = if (runningState != null) {
            (runningState.elapsedMs / 10_000f).coerceIn(0f, 1f)
        } else 1f

        StressBarDialog(
            running = runningState != null,
            progress = progress,
            result = doneState?.result,
            onApplyRecommended = {
                doneState?.result?.let { r ->
                    viewModel.switchPreset(r.recommendedPresetId)
                }
            },
            onDismiss = {
                // Reset by triggering cancel (state will go back to idle on next benchmark)
            }
        )
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 4.dp, top = 8.dp, bottom = 4.dp)
    )
}

@Composable
private fun CardContainer(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(vertical = 4.dp)) {
            content()
        }
    }
}

@Composable
private fun SelectorRow(
    title: String,
    subtitle: String,
    current: String,
    options: List<String>,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        current,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }
        if (expanded) {
            Spacer(Modifier.height(8.dp))
            options.forEach { opt ->
                val isSelected = opt == current
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            onSelect(opt)
                            expanded = false
                        }
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        opt,
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
private fun InfoRow(title: String, subtitle: String) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(2.dp))
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ClickableRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("›", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun ActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    iconTint: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(iconTint.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = iconTint)
        }
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SliderRow(
    title: String,
    subtitle: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(2.dp))
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
