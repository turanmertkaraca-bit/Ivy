package com.animestream.player.youtube

import android.util.Log
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.stream.StreamExtractor
import org.schabi.newpipe.extractor.stream.VideoStream
import org.schabi.newpipe.extractor.stream.AudioStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Resolves a YouTube URL into a playable video + audio stream URL pair
 * using NewPipeExtractor v0.24.3.
 *
 * IMPORTANT API NOTES (v0.24.3):
 *   - Localization constructor takes (languageCode, countryCode) Strings
 *   - Request class fields are PRIVATE — use url(), httpMethod(), dataToSend(), headers()
 *   - Response constructor: Response(int, String, Map<String, List<String>>, String, String)
 *
 * Stream selection policy:
 *   1. Filter video-only streams
 *   2. Pick the highest resolution ≤ user's base resolution
 *   3. Prefer MP4/avc1 over WebM/VP9 (mediacodec handles H.264 better on Mali)
 *   4. Audio: prefer m4a (itag 140) → opus (itag 251) → first audio stream
 *   5. If no separate streams: fall back to first combined stream
 */
data class ResolvedStream(
    val videoUrl: String,
    val audioUrl: String?,        // null if video is muxed
    val title: String,
    val uploader: String,
    val durationSeconds: Long,
    val thumbnailUrl: String?
)

class YouTubeResolver {

    private val TAG = "YouTubeResolver"

    init {
        // Initialize NewPipe with a simple URLConnection-based Downloader.
        // NewPipe.init() is idempotent — calling twice throws, so guard.
        try {
            NewPipe.init(SimpleDownloader(), Localization("en", "US"))
        } catch (e: Exception) {
            Log.w(TAG, "NewPipe.init already called or failed: " + e.message)
        }
    }

    fun resolve(url: String, baseResolution: String): ResolvedStream {
        val targetHeight = parseResolution(baseResolution)
        Log.i(TAG, "Resolving $url at base ≤ $baseResolution (${targetHeight}p)")

        val service = NewPipe.getService(url)
        val streamExtractor: StreamExtractor = service.getStreamExtractor(url)
        streamExtractor.fetchPage()

        val title = streamExtractor.name ?: "Untitled"
        val uploader = streamExtractor.uploaderName ?: "Unknown"
        val duration = streamExtractor.lengthInSeconds
        val thumbnail = streamExtractor.thumbnailUrl

        val videoOnlyStreams = streamExtractor.videoOnlyStreams ?: emptyList()
        val audioStreams = streamExtractor.audioStreams ?: emptyList()
        val videoStreams = streamExtractor.videoStreams ?: emptyList()

        Log.i(TAG, "Found ${videoOnlyStreams.size} video-only, ${audioStreams.size} audio, ${videoStreams.size} combined")

        val candidateVideo = pickVideoStream(videoOnlyStreams, targetHeight)
            ?: pickVideoStream(videoStreams, targetHeight)

        if (candidateVideo == null) {
            // Last-ditch fallback: first combined stream with a URL
            val fallback = videoStreams.firstOrNull { it.url != null }
            if (fallback == null) {
                throw IllegalStateException("No compatible video stream found")
            }
            Log.w(TAG, "Using combined stream fallback (no separate A/V)")
            return ResolvedStream(
                videoUrl = fallback.url,
                audioUrl = null,
                title = title,
                uploader = uploader,
                durationSeconds = duration,
                thumbnailUrl = thumbnail
            )
        }

        val audioUrl = pickAudioStream(audioStreams)

        return ResolvedStream(
            videoUrl = candidateVideo.url,
            audioUrl = audioUrl,
            title = title,
            uploader = uploader,
            durationSeconds = duration,
            thumbnailUrl = thumbnail
        )
    }

    private fun pickVideoStream(streams: List<VideoStream>, maxHeight: Int): VideoStream? {
        if (streams.isEmpty()) return null
        val codecPriority = listOf("avc1", "avc", "h264", "av01", "av1", "vp9", "vp8")

        val scored = streams.filter { it.url != null }.map { s ->
            val h = s.height ?: 0
            val formatName = s.format?.name?.lowercase() ?: ""
            val deliveryName = (s.deliveryMethod?.name ?: "").lowercase()
            val heightOk = if (h <= maxHeight) 1 else 0
            val heightScore = if (heightOk == 1) (maxHeight - h) else -1000
            val codecScore = codecPriority.indexOfFirst {
                formatName.contains(it) || deliveryName.contains(it)
            }.let { if (it == -1) 99 else it }
            Triple(s, heightScore, codecScore)
        }.sortedWith(
            compareByDescending<Pair<VideoStream, Int, Int>> { it.second }
                .thenBy { it.third }
        )

        val winner = scored.firstOrNull()?.first
        if (winner != null) {
            Log.i(TAG, "Picked video: ${winner.height}p ${winner.format?.name} ${winner.deliveryMethod}")
        }
        return winner
    }

    private fun pickAudioStream(streams: List<AudioStream>): String? {
        if (streams.isEmpty()) return null
        // Prefer m4a (itag 140) → opus (itag 251) → first available
        val m4a = streams.firstOrNull {
            it.url != null && (it.format?.name?.lowercase()?.contains("m4a") == true)
        }
        if (m4a != null) return m4a.url
        val opus = streams.firstOrNull {
            it.url != null && (it.format?.name?.lowercase()?.contains("opus") == true)
        }
        if (opus != null) return opus.url
        return streams.firstOrNull { it.url != null }?.url
    }

    private fun parseResolution(res: String): Int {
        return when (res.lowercase()) {
            "144p" -> 144
            "240p" -> 240
            "360p" -> 360
            "480p" -> 480
            "720p" -> 720
            "1080p" -> 1080
            "1440p" -> 1440
            "2160p" -> 2160
            else -> 480
        }
    }

    companion object {
        val SUPPORTED_RESOLUTIONS = listOf("144p", "240p", "360p", "480p", "720p", "1080p")
    }
}

/**
 * Minimal HttpURLConnection-based Downloader for NewPipeExtractor.
 * Bypasses OkHttp to avoid extra transitive deps.
 */
private class SimpleDownloader : Downloader() {
    override fun execute(request: Request): Response {
        val url = URL(request.url())
        val conn = (url.openConnection() as HttpURLConnection).apply {
            method = request.httpMethod()
            connectTimeout = 15_000
            readTimeout = 30_000
            instanceFollowRedirects = true
            request.headers().forEach { (k, values) ->
                values.forEach { v -> addRequestProperty(k, v) }
            }
            val body = request.dataToSend()
            if (body != null && body.isNotEmpty()) {
                doOutput = true
                outputStream.use { it.write(body) }
            }
        }

        val responseCode = conn.responseCode
        val responseMessage = conn.responseMessage ?: ""
        val responseBody = try {
            conn.inputStream?.bufferedReader()?.use { it.readText() } ?: ""
        } catch (e: Exception) {
            conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
        }
        val headers = mutableMapOf<String, List<String>>()
        conn.headerFields?.forEach { (k, v) ->
            if (k != null && v != null) headers[k] = v
        }
        val latestUrl = conn.url?.toString() ?: request.url()

        return Response(
            responseCode,
            responseMessage,
            headers,
            responseBody,
            latestUrl
        )
    }
}
