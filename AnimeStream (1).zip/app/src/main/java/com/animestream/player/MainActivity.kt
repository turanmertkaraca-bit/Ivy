package com.animestream.player

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.animestream.player.ui.HomeScreen
import com.animestream.player.ui.PlayerScreen
import com.animestream.player.ui.SettingsScreen
import com.animestream.player.ui.theme.AnimeStreamTheme
import com.animestream.player.viewmodel.PlayerViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AnimeStreamTheme {
                AppRoot(initialShareUrl = extractSharedUrl(intent))
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Trigger re-composition by sending a fresh share URL via a singleton bus
        val url = extractSharedUrl(intent)
        if (url != null) ShareBus.emit(url)
    }

    private fun extractSharedUrl(intent: Intent?): String? {
        if (intent == null) return null
        if (intent.action != Intent.ACTION_SEND) return null
        val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return null
        return text.lines().firstOrNull { it.contains("youtube.com/") || it.contains("youtu.be/") }
    }
}

// Simple in-process event bus for share intents arriving on already-running activity
object ShareBus {
    private var listener: ((String) -> Unit)? = null
    fun emit(url: String) { listener?.invoke(url) }
    fun listen(l: (String) -> Unit) { listener = l }
    fun clear() { listener = null }
}

@Composable
private fun AppRoot(initialShareUrl: String?) {
    val navController = rememberNavController()
    val viewModel: PlayerViewModel = viewModel()

    var pendingUrl by remember { mutableStateOf(initialShareUrl) }

    // Listen for late share intents (activity already running)
    LaunchedEffect(Unit) {
        ShareBus.listen { url ->
            pendingUrl = url
            navController.navigate("player?url=" + java.net.URLEncoder.encode(url, "UTF-8")) {
                popUpTo("home") { inclusive = false }
                launchSingleTop = true
            }
        }
    }

    NavHost(navController, startDestination = "home") {
        composable("home") {
            HomeScreen(
                initialUrl = pendingUrl,
                onPlay = { url ->
                    pendingUrl = url
                    navController.navigate("player?url=" + java.net.URLEncoder.encode(url, "UTF-8"))
                },
                onOpenSettings = { navController.navigate("settings") }
            )
        }
        composable("player?url={url}") { backStackEntry ->
            val encodedUrl = backStackEntry.arguments?.getString("url") ?: ""
            val url = try {
                java.net.URLDecoder.decode(encodedUrl, "UTF-8")
            } catch (e: Exception) {
                encodedUrl
            }
            LaunchedEffect(url) {
                viewModel.loadUrl(url)
            }
            PlayerScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenSettings = { navController.navigate("settings") }
            )
        }
        composable("settings") {
            SettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
