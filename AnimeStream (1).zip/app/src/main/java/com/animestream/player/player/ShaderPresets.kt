package com.animestream.player.player

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream

/**
 * All 11 shader presets from the spec.
 *
 * Preset IDs are stable strings stored in DataStore — DO NOT rename.
 * File names are relative to assets/shaders/ at build time and are
 * copied to filesDir/shaders/ at first launch.
 */
data class ShaderPreset(
    val id: String,
    val displayName: String,
    val description: String,
    val files: List<String>,       // asset filenames
    val estimatedPerf: String,     // hint shown in UI
    val tier: PresetTier           // for benchmark recommendation
) {
    val isNone: Boolean get() = files.isEmpty()
}

enum class PresetTier { NONE, FAST, BALANCED, HEAVY }

object ShaderPresets {

    private const val TAG = "ShaderPresets"
    private const val ASSET_DIR = "shaders"
    private const val FS_DIR = "shaders"

    val presets: List<ShaderPreset> = listOf(
        ShaderPreset(
            id = "none_spline36",
            displayName = "None (spline36)",
            description = "Pure mpv built-in scaler. Lightest, fastest.",
            files = emptyList(),
            estimatedPerf = "60 FPS",
            tier = PresetTier.NONE
        ),
        ShaderPreset(
            id = "anime4k_a",
            displayName = "Anime4K Mode A (lightest)",
            description = "Clamp highlights + Restore CNN M + Upscale CNN M x2. Best for clean 720p anime sources.",
            files = listOf(
                "Anime4K_Clamp_Highlights.glsl",
                "Anime4K_Restore_CNN_M.glsl",
                "Anime4K_Upscale_CNN_x2_M.glsl"
            ),
            estimatedPerf = "55–60 FPS",
            tier = PresetTier.FAST
        ),
        ShaderPreset(
            id = "anime4k_b",
            displayName = "Anime4K Mode B (denoise)",
            description = "Adds S-size restore+upscale pass on top of Mode A. For noisy 480p sources.",
            files = listOf(
                "Anime4K_Clamp_Highlights.glsl",
                "Anime4K_Restore_CNN_S.glsl",
                "Anime4K_Upscale_CNN_x2_S.glsl",
                "Anime4K_Restore_CNN_M.glsl",
                "Anime4K_Upscale_CNN_x2_M.glsl"
            ),
            estimatedPerf = "40–50 FPS",
            tier = PresetTier.BALANCED
        ),
        ShaderPreset(
            id = "anime4k_c",
            displayName = "Anime4K Mode C (line darkening, heaviest)",
            description = "Restore CNN S+L with Upscale CNN S+L. Heaviest anime preset, deepest line darkening.",
            files = listOf(
                "Anime4K_Clamp_Highlights.glsl",
                "Anime4K_Restore_CNN_S.glsl",
                "Anime4K_Upscale_CNN_x2_S.glsl",
                "Anime4K_Restore_CNN_L.glsl",
                "Anime4K_Upscale_CNN_x2_L.glsl"
            ),
            estimatedPerf = "25–35 FPS",
            tier = PresetTier.HEAVY
        ),
        ShaderPreset(
            id = "anime4k_b_denoise",
            displayName = "Anime4K Mode B + Denoise",
            description = "Mode B with added denoise upscale pass. Best for grainy encodes.",
            files = listOf(
                "Anime4K_Clamp_Highlights.glsl",
                "Anime4K_Restore_CNN_S.glsl",
                "Anime4K_Upscale_CNN_x2_S.glsl",
                "Anime4K_Restore_CNN_M.glsl",
                "Anime4K_Upscale_CNN_x2_M.glsl",
                "Anime4K_Upscale_Denoise_CNN_x2_M.glsl"
            ),
            estimatedPerf = "35–45 FPS",
            tier = PresetTier.BALANCED
        ),
        ShaderPreset(
            id = "fsrcnnx_8",
            displayName = "FSRCNNX x2 8-0-4-1",
            description = "Lightweight neural net. Balanced quality and performance.",
            files = listOf("FSRCNNX_x2_8-0-4-1.glsl"),
            estimatedPerf = "50–58 FPS",
            tier = PresetTier.BALANCED
        ),
        ShaderPreset(
            id = "fsrcnnx_16",
            displayName = "FSRCNNX x2 16-0-4-1 (heavier)",
            description = "Heavier neural net for higher quality output.",
            files = listOf("FSRCNNX_x2_16-0-4-1.glsl"),
            estimatedPerf = "30–40 FPS",
            tier = PresetTier.HEAVY
        ),
        ShaderPreset(
            id = "artcnn_c4f32",
            displayName = "ArtCNN C4F32",
            description = "Newer neural net with very clean edge reproduction.",
            files = listOf("ArtCNN_C4F32_Depth_toToSpace.glsl"),
            estimatedPerf = "45–55 FPS",
            tier = PresetTier.BALANCED
        ),
        ShaderPreset(
            id = "ravu_lite_r4",
            displayName = "RAVU Lite r4 (live-action)",
            description = "Best for non-anime / live-action content. Fastest quality option.",
            files = listOf("ravu-lite-r4.hook"),
            estimatedPerf = "58–60 FPS",
            tier = PresetTier.FAST
        ),
        ShaderPreset(
            id = "ravu_lite_r3",
            displayName = "RAVU Lite r3 (faster)",
            description = "Lighter RAVU variant — slightly lower quality, slightly faster.",
            files = listOf("ravu-lite-r3.hook"),
            estimatedPerf = "60 FPS",
            tier = PresetTier.FAST
        ),
        ShaderPreset(
            id = "krig_bilateral",
            displayName = "KrigBilateral (chroma upscaler)",
            description = "Upscales chroma planes. Often combined with luma shaders for full-quality output.",
            files = listOf("KrigBilateral.hook"),
            estimatedPerf = "58–60 FPS",
            tier = PresetTier.FAST
        )
    )

    val assetFiles: List<String> = presets.flatMap { it.files }.distinct()

    fun byId(id: String): ShaderPreset =
        presets.firstOrNull { it.id == id } ?: presets.first { it.id == "ravu_lite_r4" }

    /**
     * Copy shaders from assets to filesDir/shaders/ so mpv can load them by path.
     * Returns the directory where shaders live.
     */
    fun ensureExtracted(context: Context): File {
        val outDir = File(context.filesDir, FS_DIR)
        if (!outDir.exists()) outDir.mkdirs()

        for (assetName in assetFiles) {
            val outFile = File(outDir, assetName)
            if (outFile.exists() && outFile.length() > 0) continue
            try {
                context.assets.open("$ASSET_DIR/$assetName").use { input ->
                    FileOutputStream(outFile).use { output -> input.copyTo(output) }
                }
                Log.d(TAG, "Extracted shader: $assetName (${outFile.length()} bytes)")
            } catch (e: Exception) {
                Log.w(TAG, "Missing shader asset: $assetName — " + e.message)
            }
        }
        return outDir
    }

    fun pathsFor(preset: ShaderPreset, shaderDir: File): List<String> =
        preset.files.map { File(shaderDir, it).absolutePath }
}
