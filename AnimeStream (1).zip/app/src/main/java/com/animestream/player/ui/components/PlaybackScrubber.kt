package com.animestream.player.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/**
 * Draggable playback scrubber.
 * - position: seconds played
 * - duration: total seconds
 * - onSeek: called with new position (seconds) when user lifts finger
 */
@Composable
fun PlaybackScrubber(
    position: Double,
    duration: Double,
    buffered: Double = 0.0,
    onSeek: (Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalSecs = if (duration > 0) duration else 1.0
    val progress = (position / totalSecs).coerceIn(0.0, 1.0).toFloat()
    val bufferedProgress = (buffered / totalSecs).coerceIn(0.0, 1.0).toFloat()

    var dragX by remember { mutableStateOf(0f) }
    var dragging by remember { mutableStateOf(false) }
    var canvasWidth by remember { mutableStateOf(0f) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(28.dp)
            .pointerInput(totalSecs) {
                detectDragGestures(
                    onDragStart = { offset ->
                        dragging = true
                        canvasWidth = size.width.toFloat()
                        dragX = offset.x
                    },
                    onDragEnd = {
                        if (canvasWidth > 0) {
                            val ratio = (dragX / canvasWidth).coerceIn(0f, 1f)
                            onSeek((ratio * totalSecs))
                        }
                        dragging = false
                    },
                    onDragCancel = { dragging = false }
                ) { change, _ ->
                    dragX = change.position.x
                }
            }
            .pointerInput(totalSecs) {
                // tap-to-seek
                androidx.compose.foundation.gestures.detectTapGestures(
                    onTap = { offset ->
                        if (size.width > 0) {
                            val ratio = (offset.x / size.width).coerceIn(0f, 1f)
                            onSeek((ratio * totalSecs))
                        }
                    }
                )
            }
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .align(Alignment.Center)
                .clip(RoundedCornerShape(2.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            canvasWidth = size.width
            val barHeight = size.height
            // Buffered
            if (bufferedProgress > 0) {
                drawRect(
                    color = Color.White.copy(alpha = 0.25f),
                    size = androidx.compose.ui.geometry.Size(size.width * bufferedProgress, barHeight)
                )
            }
            // Progress
            val liveRatio = if (dragging && canvasWidth > 0) {
                (dragX / canvasWidth).coerceIn(0f, 1f)
            } else {
                progress
            }
            drawRect(
                color = MaterialTheme.colorScheme.primary,
                size = androidx.compose.ui.geometry.Size(size.width * liveRatio, barHeight)
            )
            // Thumb
            val thumbX = size.width * liveRatio
            drawCircle(
                color = MaterialTheme.colorScheme.primary,
                radius = 7.dp.toPx(),
                center = Offset(thumbX, barHeight / 2)
            )
        }
    }
}

fun formatTime(seconds: Double): String {
    if (seconds < 0 || seconds.isNaN() || seconds.isInfinite()) return "00:00"
    val total = seconds.toLong()
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) {
        String.format("%d:%02d:%02d", h, m, s)
    } else {
        String.format("%02d:%02d", m, s)
    }
}
