package com.animestream.player.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "resume_positions")
data class ResumePosition(
    @PrimaryKey val videoId: String,
    val positionSeconds: Long,
    val durationSeconds: Long,
    val title: String,
    val updatedAt: Long
)

@Dao
interface ResumeDao {
    @Query("SELECT * FROM resume_positions WHERE videoId = :videoId")
    fun get(videoId: String): Flow<ResumePosition?>

    @Query("SELECT * FROM resume_positions ORDER BY updatedAt DESC")
    fun all(): Flow<List<ResumePosition>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(position: ResumePosition)

    @Query("DELETE FROM resume_positions WHERE videoId = :videoId")
    suspend fun delete(videoId: String)
}

@Database(entities = [ResumePosition::class], version = 1, exportSchema = false)
abstract class AnimeStreamDatabase : RoomDatabase() {
    abstract fun resumeDao(): ResumeDao

    companion object {
        @Volatile
        private var INSTANCE: AnimeStreamDatabase? = null

        fun get(context: Context): AnimeStreamDatabase {
            return INSTANCE ?: synchronized(this) {
                val db = Room.databaseBuilder(
                    context.applicationContext,
                    AnimeStreamDatabase::class.java,
                    "animestream.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = db
                db
            }
        }
    }
}
