package com.animestream.player.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import android.util.Log
import android.view.SurfaceView
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BrightnessHigh
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import `is`.xyz.mpv.BaseMPVView
import com.animestream.player.player.ShaderPresets
import com.animestream.player.ui.components.PlaybackScrubber
import com.animestream.player.ui.components.formatTime
import com.animestream.player.viewmodel.PlayerUiState
import com.animestream.player.viewmodel.PlayerViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

@Composable
fun PlayerScreen(
    viewModel: PlayerViewModel,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val position by viewModel.position.collectAsState()
    val duration by viewModel.duration.collectAsState()
    val paused by viewModel.paused.collectAsState()
    val fps by viewModel.fps.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val currentTitle by viewModel.currentTitle.collectAsState()

    val scope = rememberCoroutineScope()

    // Lock to landscape on enter, restore on leave
    DisposableEffect(Unit) {
        val activity = context as? Activity
        val originalOrientation = activity?.requestedOrientation
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            activity?.requestedOrientation = originalOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // Track brightness/volume changes for on-screen indicators
    var brightnessOverlay by remember { mutableFloatStateOf(-1f) }
    var volumeOverlay by remember { mutableFloatStateOf(-1f) }
    var overlayFadeTime by remember { mutableStateOf(0L) }

    LaunchedEffect(overlayFadeTime) {
        if (overlayFadeTime > 0) {
            delay(800)
            overlayFadeTime = 0
            brightnessOverlay = -1f
            volumeOverlay = -1f
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // ---- MPV surface ----
        AndroidView(
            factory = { ctx ->
                BaseMPVView(ctx).apply {
                    viewModel.initPlayer()
                    viewModel.player.bind(this)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // ---- Gesture layer ----
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    var lastTapTime = 0L
                    var lastTapX = 0f
                    detectTapGestures(
                        onDoubleTap = { offset ->
                            val now = System.currentTimeMillis()
                            val width = size.width
                            val isLeft = offset.x < width / 2
                            val delta = if (isLeft) -10.0 else 10.0
                            viewModel.seekBy(delta)
                            overlayFadeTime = now
                            brightnessOverlay = -2f  // show "seek" indicator
                        },
                        onTap = {
                            // toggle UI visibility handled by controlsVisible state
                        }
                    )
                }
                .pointerInput(Unit) {
                    var startY = 0f
                    var currentSide = 0  // -1 left (brightness), 1 right (volume)
                    detectDragGestures(
                        onDragStart = { offset ->
                            startY = offset.y
                            currentSide = if (offset.x < size.width / 2) -1 else 1
                        }
                    ) { change, _ ->
                        val dy = startY - change.position.y  // positive = up
                        if (abs(dy) > 8) {
                            val activity = context as? Activity
                            val window = activity?.window
                            val layoutParams = window?.attributes
                            if (currentSide == -1 && layoutParams != null) {
                                // Brightness (high sensitivity)
                                val normalized = (dy / size.height).coerceIn(-1f, 1f)
                                val delta = normalized * settings.brightnessSensitivity * 0.5f
                                val current = layoutParams.screenBrightness.let {
                                    if (it < 0) 0.5f else it
                                }
                                val newB = (current + delta).coerceIn(0f, 1f)
                                layoutParams.screenBrightness = newB
                                window.attributes = layoutParams
                                brightnessOverlay = newB
                                volumeOverlay = -1f
                                overlayFadeTime = System.currentTimeMillis()
                            } else if (currentSide == 1 && activity != null) {
                                // Volume (low sensitivity)
                                val audioManager = context.getSystemService(android.content.Context.AUDIO_SERVICE)
                                        as android.media.AudioManager
                                val max = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                                val current = audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                                val normalized = (dy / size.height).coerceIn(-1f, 1f)
                                val delta = (normalized * settings.volumeSensitivity * max * 0.5f).toInt()
                                val newVol = (current + delta).coerceIn(0, max)
                                audioManager.setStreamVolume(
                                    android.media.AudioManager.STREAM_MUSIC,
                                    newVol,
                                    android.media.AudioManager.FLAG_SHOW_UI
                                )
                                volumeOverlay = newVol.toFloat() / max
                                brightnessOverlay = -1f
                                overlayFadeTime = System.currentTimeMillis()
                            }
                            startY = change.position.y
                        }
                    }
                }
        )

        // ---- Top bar (title + back + settings) ----
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .background(Color.Black.copy(alpha = 0.5f))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text(
                text = currentTitle.ifEmpty { (uiState as? PlayerUiState.Ready)?.stream?.title ?: "AnimeStream" },
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                maxLines = 1,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
            }
        }

        // ---- Bottom playback bar ----
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.6f))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.togglePause() }) {
                    Icon(
                        imageVector = if (paused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = if (paused) "Play" else "Pause",
                        tint = Color.White
                    )
                }
                Text(
                    text = formatTime(position),
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White
                )
                Spacer(Modifier.width(12.dp))
                PlaybackScrubber(
                    position = position,
                    duration = duration,
                    onSeek = { viewModel.seekTo(it) },
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    text = formatTime(duration),
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = String.format("%.0f", fps),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.tertiary,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // ---- Brightness / volume overlay indicators ----
        if (brightnessOverlay >= 0f) {
            GestureIndicator(
                icon = Icons.Default.BrightnessHigh,
                value = (brightnessOverlay * 100).toInt(),
                label = "BRIGHTNESS",
                modifier = Modifier.align(Alignment.CenterStart).padding(start = 32.dp)
            )
        }
        if (volumeOverlay >= 0f) {
            GestureIndicator(
                icon = Icons.Default.VolumeUp,
                value = (volumeOverlay * 100).toInt(),
                label = "VOLUME",
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 32.dp)
            )
        }

        // ---- Seek indicator (when double-tap seeking) ----
        if (brightnessOverlay == -2f) {
            Box(
                modifier = Modifier.align(Alignment.Center),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "±10s",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // ---- Loading overlay ----
        if (uiState is PlayerUiState.Loading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.7f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(12.dp))
                    Text("Resolving stream…", color = Color.White)
                }
            }
        }

        // ---- Error overlay ----
        if (uiState is PlayerUiState.Error) {
            val msg = (uiState as PlayerUiState.Error).message
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(32.dp)
                ) {
                    Text(
                        "Playback failed",
                        color = Color.White,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(msg, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(16.dp))
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                    }
                }
            }
        }

        // ---- Auto-play when stream is ready ----
        LaunchedEffect(uiState) {
            val ready = uiState as? PlayerUiState.Ready
            if (ready != null) {
                delay(100)
                viewModel.playStream(ready.stream)
            }
        }
    }
}

@Composable
private fun GestureIndicator(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: Int,
    label: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color.Black.copy(alpha = 0.7f))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(4.dp))
        Text("$value%", color = Color.White, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
    }
}


