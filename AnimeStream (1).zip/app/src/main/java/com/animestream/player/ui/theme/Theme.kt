package com.animestream.player.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import android.os.Build

private val DarkColors = darkColorScheme(
    primary = Sakura,
    onPrimary = Ink,
    primaryContainer = Mist,
    onPrimaryContainer = Bone,
    secondary = Aurora,
    onSecondary = Bone,
    secondaryContainer = Slate,
    onSecondaryContainer = Bone,
    tertiary = Sky,
    onTertiary = Ink,
    background = Ink,
    onBackground = Bone,
    surface = Charcoal,
    onSurface = Bone,
    surfaceVariant = Slate,
    onSurfaceVariant = Ash,
    outline = Hazel,
    outlineVariant = Mist,
    error = Coral,
    onError = Ink,
    errorContainer = Coral,
    onErrorContainer = Ink
)

private val LightColors = lightColorScheme(
    primary = Sakura,
    onPrimary = Ink,
    secondary = Aurora,
    onSecondary = Bone,
    tertiary = Sky,
    onTertiary = Ink,
    background = Bone,
    onBackground = Ink,
    surface = Bone,
    onSurface = Ink
)

@Composable
fun AnimeStreamTheme(
    darkTheme: Boolean = true,  // force dark — it's a video player
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AnimeStreamTypography,
        content = content
    )
}
