package com.animestream.player.ui.theme

import androidx.compose.ui.graphics.Color

// Dark-first palette tuned for video player aesthetic
val Ink = Color(0xFF0A0B0F)         // background
val Charcoal = Color(0xFF15171E)    // surface
val Slate = Color(0xFF1F232C)       // surfaceVariant
val Mist = Color(0xFF2A2F3A)        // elevated surface
val Bone = Color(0xFFE8EAF0)        // primary text
val Ash = Color(0xFF9CA3AF)         // secondary text
val Hazel = Color(0xFF6B7280)       // tertiary text / disabled

// Accents
val Sakura = Color(0xFFFF6B9D)      // primary accent (warm pink)
val Aurora = Color(0xFF7C5CFF)      // secondary accent (purple)
val Neon = Color(0xFF4ADE80)        // success / green
val Marigold = Color(0xFFFBBF24)    // warning / yellow
val Coral = Color(0xFFFF5252)       // danger / red
val Sky = Color(0xFF38BDF8)         // info / cyan
