package com.animestream.player

import android.app.Application
import android.util.Log
import org.schabi.newpipe.extractor.NewPipe

class AnimeStreamApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.i("AnimeStreamApp", "Application created")
    }
}
