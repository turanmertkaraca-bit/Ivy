@file:Suppress("unused")
package `is`.xyz.mpv

import android.content.Context
import android.graphics.Bitmap
import android.view.Surface

/**
 * libmpv JNI bridge — verbatim from mpv-android (github.com/mpv-android/mpv-android).
 *
 * The native function names in libplayer.so are derived from this class's
 * fully-qualified name (is.xyz.mpv.MPVLib). DO NOT rename the package or
 * the class — the JNI symbols won't resolve.
 *
 * The .so files required at runtime (loaded in this order):
 *   1. libmpv.so  — the mpv engine + ffmpeg + libplacebo
 *   2. libplayer.so — the JNI bridge (this Kotlin file calls into it)
 *
 * Plus transitive deps that libmpv.so dlopens:
 *   libavcodec.so, libavformat.so, libavfilter.so, libavutil.so,
 *   libswresample.so, libswscale.so, libavdevice.so, libc++_shared.so
 *
 * All of these are extracted from the official mpv-android arm64-v8a release APK
 * by the GitHub Actions workflow (.github/workflows/build.yml).
 */
object MPVLib {
    init {
        // Load order matters: libmpv first (engine), then libplayer (bridge)
        val libs = arrayOf("mpv", "player")
        for (lib in libs) {
            try {
                System.loadLibrary(lib)
            } catch (e: UnsatisfiedLinkError) {
                android.util.Log.e("MPVLib", "Failed to load lib" + lib + ".so: " + e.message)
                throw e
            }
        }
    }

    // ---- Lifecycle ----
    external fun create(appctx: Context)
    external fun init()
    external fun destroy()
    external fun attachSurface(surface: Surface)
    external fun detachSurface()

    // ---- Commands ----
    external fun command(cmd: Array<out String>)

    // ---- Options (must be called BEFORE init) ----
    external fun setOptionString(name: String, value: String): Int

    // ---- Thumbnail (unused but exported) ----
    external fun grabThumbnail(dimension: Int): Bitmap?

    // ---- Property getters (nullable — return null if property doesn't exist) ----
    external fun getPropertyInt(property: String): Int?
    external fun setPropertyInt(property: String, value: Int)
    external fun getPropertyDouble(property: String): Double?
    external fun setPropertyDouble(property: String, value: Double)
    external fun getPropertyBoolean(property: String): Boolean?
    external fun setPropertyBoolean(property: String, value: Boolean)
    external fun getPropertyString(property: String): String?
    external fun setPropertyString(property: String, value: String)

    // ---- Property observation ----
    external fun observeProperty(property: String, format: Int)

    private val observers = mutableListOf<EventObserver>()

    @JvmStatic
    fun addObserver(o: EventObserver) {
        synchronized(observers) { observers.add(o) }
    }

    @JvmStatic
    fun removeObserver(o: EventObserver) {
        synchronized(observers) { observers.remove(o) }
    }

    // Called from JNI (libplayer.so) when an observed property changes.
    @JvmStatic
    fun eventProperty(property: String, value: Long) {
        synchronized(observers) {
            for (o in observers) o.eventProperty(property, value)
        }
    }

    @JvmStatic
    fun eventProperty(property: String, value: Boolean) {
        synchronized(observers) {
            for (o in observers) o.eventProperty(property, value)
        }
    }

    @JvmStatic
    fun eventProperty(property: String, value: Double) {
        synchronized(observers) {
            for (o in observers) o.eventProperty(property, value)
        }
    }

    @JvmStatic
    fun eventProperty(property: String, value: String) {
        synchronized(observers) {
            for (o in observers) o.eventProperty(property, value)
        }
    }

    @JvmStatic
    fun eventProperty(property: String) {
        synchronized(observers) {
            for (o in observers) o.eventProperty(property)
        }
    }

    @JvmStatic
    fun event(eventId: Int) {
        synchronized(observers) {
            for (o in observers) o.event(eventId)
        }
    }

    interface EventObserver {
        fun eventProperty(property: String)
        fun eventProperty(property: String, value: Long)
        fun eventProperty(property: String, value: Boolean)
        fun eventProperty(property: String, value: String)
        fun eventProperty(property: String, value: Double)
        fun event(eventId: Int)
    }

    object MpvFormat {
        const val MPV_FORMAT_NONE: Int = 0
        const val MPV_FORMAT_STRING: Int = 1
        const val MPV_FORMAT_OSD_STRING: Int = 2
        const val MPV_FORMAT_FLAG: Int = 3
        const val MPV_FORMAT_INT64: Int = 4
        const val MPV_FORMAT_DOUBLE: Int = 5
        const val MPV_FORMAT_NODE: Int = 6
        const val MPV_FORMAT_NODE_ARRAY: Int = 7
        const val MPV_FORMAT_NODE_MAP: Int = 8
        const val MPV_FORMAT_BYTE_ARRAY: Int = 9
    }

    object MpvEvent {
        const val MPV_EVENT_NONE: Int = 0
        const val MPV_EVENT_SHUTDOWN: Int = 1
        const val MPV_EVENT_LOG_MESSAGE: Int = 2
        const val MPV_EVENT_GET_PROPERTY_REPLY: Int = 3
        const val MPV_EVENT_SET_PROPERTY_REPLY: Int = 4
        const val MPV_EVENT_COMMAND_REPLY: Int = 5
        const val MPV_EVENT_START_FILE: Int = 6
        const val MPV_EVENT_END_FILE: Int = 7
        const val MPV_EVENT_FILE_LOADED: Int = 8
        const val MPV_EVENT_IDLE: Int = 11
        const val MPV_EVENT_TICK: Int = 14
        const val MPV_EVENT_CLIENT_MESSAGE: Int = 16
        const val MPV_EVENT_VIDEO_RECONFIG: Int = 17
        const val MPV_EVENT_AUDIO_RECONFIG: Int = 18
        const val MPV_EVENT_SEEK: Int = 20
        const val MPV_EVENT_PLAYBACK_RESTART: Int = 21
        const val MPV_EVENT_PROPERTY_CHANGE: Int = 22
        const val MPV_EVENT_QUEUE_OVERFLOW: Int = 24
        const val MPV_EVENT_HOOK: Int = 25
    }
}
