package `is`.xyz.mpv

import android.content.Context
import android.graphics.PixelFormat
import android.util.AttributeSet
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView

/**
 * SurfaceView that hosts libmpv's video output.
 *
 * Adapted from mpv-android's BaseMPVView (MIT). Uses the real MPVLib API:
 *   - create(context)        — instantiate native mpv instance
 *   - setOptionString(k, v)  — set option BEFORE init()
 *   - init()                 — start mpv
 *   - attachSurface(surface) — bind to this SurfaceView's surface
 *   - observeProperty()      — register for property change events
 *
 * The view self-configures on first surface creation. Callers should call
 * [initPlayer] once to set options + init, then [destroyPlayer] on disposal.
 */
open class BaseMPVView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : SurfaceView(context, attrs, defStyleAttr), SurfaceHolder.Callback {

    protected val TAG: String = "BaseMPVView"

    private var surfaceAttached = false
    private var mpvInitialized = false

    init {
        holder.addCallback(this)
        holder.setFormat(PixelFormat.RGBA_8888)
    }

    /**
     * Configure mpv options, create the mpv instance, and init.
     * Call this ONCE before [loadfile].
     *
     * Subclasses can override [initOptions] to add more options.
     */
    fun initPlayer(
        hwdec: Boolean,
        gpuNext: Boolean,
        shaderPresetPaths: List<String>
    ) {
        if (mpvInitialized) {
            Log.w(TAG, "initPlayer called twice — ignoring")
            return
        }

        MPVLib.create(context.applicationContext)

        // ---- Defaults that apply to every Android device ----
        MPVLib.setOptionString("profile", "fast")
        MPVLib.setOptionString("vo", if (gpuNext) "gpu-next" else "gpu")
        MPVLib.setOptionString("gpu-context", "android")
        MPVLib.setOptionString("opengl-es", "yes")

        val hwdecValue = if (hwdec) "mediacodec-copy" else "no"
        MPVLib.setOptionString("hwdec", hwdecValue)
        MPVLib.setOptionString("hwdec-codecs", "h264,hevc,mpeg4,mpeg2video,vp8,vp9,av1")

        MPVLib.setOptionString("ao", "audiotrack,opensless")
        MPVLib.setOptionString("audio-channels", "auto-safe")
        MPVLib.setOptionString("volume-max", "100")

        // Display FPS — match refresh rate for smooth playback
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            val disp = androidx.core.content.ContextCompat.getDisplayOrDefault(context)
            val refreshRate = disp.mode.refreshRate
            Log.v(TAG, "Display FPS: $refreshRate")
            MPVLib.setOptionString("display-fps-override", refreshRate.toString())
        }

        // Cache — limited on mobile
        val cacheMegs = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O_MR1) 64 else 32
        MPVLib.setOptionString("demuxer-max-bytes", (cacheMegs * 1024 * 1024).toString())
        MPVLib.setOptionString("demuxer-max-back-bytes", (cacheMegs * 1024 * 1024).toString())

        // Aspect ratio handling
        MPVLib.setOptionString("keepaspect", "yes")
        MPVLib.setOptionString("keepaspect-window", "no")
        MPVLib.setOptionString("force-window", "yes")

        // Default scalers — overridden by shaders when a preset is active
        MPVLib.setOptionString("scale", "spline36")
        MPVLib.setOptionString("dscale", "mitchell")
        MPVLib.setOptionString("cscale", "bilinear")

        // TLS
        MPVLib.setOptionString("tls-verify", "yes")

        // Shaders — colon-separated filesystem paths
        if (shaderPresetPaths.isNotEmpty()) {
            val joined = shaderPresetPaths.joinToString(":")
            MPVLib.setOptionString("glsl-shaders", joined)
            Log.i(TAG, "Shader preset: ${shaderPresetPaths.size} files")
        } else {
            Log.i(TAG, "No shaders — using spline36 only")
        }

        // Subclass hook
        initOptions()

        // Finally, init
        MPVLib.init()
        mpvInitialized = true

        postInitOptions()
        Log.i(TAG, "mpv initialized: hwdec=$hwdecValue vo=" + (if (gpuNext) "gpu-next" else "gpu"))
    }

    /** Override to add extra options between create() and init(). */
    protected open fun initOptions() {}
    /** Override to add extra options after init(). */
    protected open fun postInitOptions() {}

    fun destroyPlayer() {
        if (!mpvInitialized) return
        if (surfaceAttached) {
            MPVLib.detachSurface()
            surfaceAttached = false
        }
        MPVLib.destroy()
        mpvInitialized = false
        Log.i(TAG, "mpv destroyed")
    }

    fun isMpvInitialized(): Boolean = mpvInitialized

    // ---- SurfaceHolder.Callback ----

    override fun surfaceCreated(holder: SurfaceHolder) {
        if (!mpvInitialized) return
        val surface = holder.surface
        if (surface != null && surface.isValid) {
            MPVLib.attachSurface(surface)
            surfaceAttached = true
            Log.i(TAG, "Surface attached")
        }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        // mpv handles resize internally
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        if (surfaceAttached && mpvInitialized) {
            MPVLib.detachSurface()
            surfaceAttached = false
            Log.i(TAG, "Surface detached")
        }
    }
}
