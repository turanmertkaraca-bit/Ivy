# This folder is populated by fetch_shaders.sh
# Re-run that script from the project root to download all Anime4K, FSRCNNX,
# ArtCNN, RAVU, and KrigBilateral shader files.
#
# The GitHub Actions workflow calls fetch_shaders.sh automatically before building.
