# Place libmpv.so here.
# See README.md "How to obtain the libmpv AAR" for instructions.
# Required file: app/src/main/jniLibs/arm64-v8a/libmpv.so
