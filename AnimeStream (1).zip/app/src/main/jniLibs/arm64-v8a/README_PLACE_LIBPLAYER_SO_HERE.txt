# Place libplayer.so here (the JNI bridge that MPVLib.kt calls into).
# See README.md "How to obtain the libmpv AAR" for instructions.
# Required file: app/src/main/jniLibs/arm64-v8a/libplayer.so
