#!/usr/bin/env bash
#
# fetch_shaders.sh — download all shader files into app/src/main/assets/shaders/
#
# Sources:
#   - Anime4K v3.x          github.com/bloc97/Anime4K
#   - FSRCNNX                github.com/igv/FSRCNN-TensorFlow
#   - ArtCNN                 github.com/TianZerL/Anime4KCPP
#   - RAVU / KrigBilateral   github.com/bjin/mpv-prescalers
#
# Safe to re-run — skips files that already exist with non-zero size.
#
set -e

ASSET_DIR="app/src/main/assets/shaders"
mkdir -p "$ASSET_DIR"

ANIME4K_BASE="https://raw.githubusercontent.com/bloc97/Anime4K/master/glsl"
FSRCNNX_BASE="https://raw.githubusercontent.com/igv/FSRCNN-TensorFlow/master"
ARTCNN_BASE="https://raw.githubusercontent.com/TianZerL/Anime4KCPP/master/shaders/glsl/ArtCNN"
RAVU_BASE="https://raw.githubusercontent.com/bjin/mpv-prescalers/master"

fetch() {
    local url="$1"
    local out="$2"
    if [ -s "$out" ]; then
        echo "[skip] $out already exists"
        return 0
    fi
    echo "[get]  $out"
    for attempt in 1 2 3; do
        if curl -fsSL -o "$out" "$url"; then
            echo "       OK ($(wc -c < "$out") bytes)"
            return 0
        fi
        echo "       retry $attempt…"
        sleep 1
    done
    echo "       FAILED — $url"
    # Don't exit on individual failures; some files may move upstream
    return 1
}

echo "== Anime4K v3.x =="
fetch "$ANIME4K_BASE/Anime4K_Clamp_Highlights.glsl"             "$ASSET_DIR/Anime4K_Clamp_Highlights.glsl"
fetch "$ANIME4K_BASE/Anime4K_Restore_CNN_S.glsl"                "$ASSET_DIR/Anime4K_Restore_CNN_S.glsl"
fetch "$ANIME4K_BASE/Anime4K_Restore_CNN_M.glsl"                "$ASSET_DIR/Anime4K_Restore_CNN_M.glsl"
fetch "$ANIME4K_BASE/Anime4K_Restore_CNN_L.glsl"                "$ASSET_DIR/Anime4K_Restore_CNN_L.glsl"
fetch "$ANIME4K_BASE/Anime4K_Restore_CNN_VL.glsl"               "$ASSET_DIR/Anime4K_Restore_CNN_VL.glsl"
fetch "$ANIME4K_BASE/Anime4K_Upscale_CNN_x2_S.glsl"             "$ASSET_DIR/Anime4K_Upscale_CNN_x2_S.glsl"
fetch "$ANIME4K_BASE/Anime4K_Upscale_CNN_x2_M.glsl"             "$ASSET_DIR/Anime4K_Upscale_CNN_x2_M.glsl"
fetch "$ANIME4K_BASE/Anime4K_Upscale_CNN_x2_L.glsl"             "$ASSET_DIR/Anime4K_Upscale_CNN_x2_L.glsl"
fetch "$ANIME4K_BASE/Anime4K_Upscale_CNN_x2_VL.glsl"            "$ASSET_DIR/Anime4K_Upscale_CNN_x2_VL.glsl"
fetch "$ANIME4K_BASE/Anime4K_Upscale_Denoise_CNN_x2_S.glsl"     "$ASSET_DIR/Anime4K_Upscale_Denoise_CNN_x2_S.glsl"
fetch "$ANIME4K_BASE/Anime4K_Upscale_Denoise_CNN_x2_M.glsl"     "$ASSET_DIR/Anime4K_Upscale_Denoise_CNN_x2_M.glsl"
fetch "$ANIME4K_BASE/Anime4K_Upscale_Denoise_CNN_x2_L.glsl"     "$ASSET_DIR/Anime4K_Upscale_Denoise_CNN_x2_L.glsl"
fetch "$ANIME4K_BASE/Anime4K_Upscale_Denoise_CNN_x2_VL.glsl"    "$ASSET_DIR/Anime4K_Upscale_Denoise_CNN_x2_VL.glsl"
fetch "$ANIME4K_BASE/Anime4K_Denoise_Bilateral_Mode.glsl"       "$ASSET_DIR/Anime4K_Denoise_Bilateral_Mode.glsl"

echo "== FSRCNNX =="
fetch "$FSRCNNX_BASE/FSRCNNX_x2_8-0-4-1.glsl"                   "$ASSET_DIR/FSRCNNX_x2_8-0-4-1.glsl"
fetch "$FSRCNNX_BASE/FSRCNNX_x2_16-0-4-1.glsl"                  "$ASSET_DIR/FSRCNNX_x2_16-0-4-1.glsl"

echo "== ArtCNN =="
fetch "$ARTCNN_BASE/ArtCNN_C4F32_Depth_toToSpace.glsl"          "$ASSET_DIR/ArtCNN_C4F32_Depth_toToSpace.glsl"

echo "== RAVU + KrigBilateral =="
fetch "$RAVU_BASE/ravu-lite-r3.hook"                            "$ASSET_DIR/ravu-lite-r3.hook"
fetch "$RAVU_BASE/ravu-lite-r4.hook"                            "$ASSET_DIR/ravu-lite-r4.hook"
fetch "$RAVU_BASE/KrigBilateral.hook"                           "$ASSET_DIR/KrigBilateral.hook"
fetch "$RAVU_BASE/SSimDownscaler.hook"                          "$ASSET_DIR/SSimDownscaler.hook"

echo ""
echo "== Summary =="
TOTAL=$(ls -1 "$ASSET_DIR" 2>/dev/null | wc -l)
echo "Shader files present: $TOTAL"
ls -la "$ASSET_DIR"
echo ""
echo "If any files show FAILED above, check upstream repo paths — they may have moved."
