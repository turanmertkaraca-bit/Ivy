#!/usr/bin/env bash
#
# fetch_shaders.sh — download all shader files into app/src/main/assets/shaders/
#
# Sources (with fallbacks where possible):
#   - Anime4K v3.x         dyphire/mpv-config (mirror of bloc97/Anime4K)
#   - FSRCNNX              dyphire/mpv-config (mirror of igv/FSRCNN-TensorFlow)
#   - ArtCNN               dyphire/mpv-config (Ani4K_ArtCNN variant — works same as ArtCNN)
#   - RAVU                 bjin/mpv-prescalers
#   - KrigBilateral        igv gist (a015fc885d5c22e6891820ad89555637)
#   - SSimDownscaler       igv gist (36508af3ffc84410fe39761d6969be10)
#
# Safe to re-run — skips files that already exist with non-zero size.
# Individual file failures are logged but DON'T abort the script.
# (The script's final exit code reflects only critical failures.)
#

ASSET_DIR="app/src/main/assets/shaders"
mkdir -p "$ASSET_DIR"

# Primary mirrors
DYPHIRE_BASE="https://raw.githubusercontent.com/dyphire/mpv-config/master/shaders"
BJIN_BASE="https://raw.githubusercontent.com/bjin/mpv-prescalers/master"
KRIG_GIST="https://gist.githubusercontent.com/igv/a015fc885d5c22e6891820ad89555637/raw"
SSIM_GIST="https://gist.githubusercontent.com/igv/36508af3ffc84410fe39761d6969be10/raw"

# Fallback: igv's FSRCNN-TensorFlow repo (in case dyphire mirror goes down)
# Note: igv's repo restructured — files may not be at root. dyphire mirror is more reliable.

FAILED_COUNT=0
SUCCESS_COUNT=0
SKIP_COUNT=0

# fetch <output_filename> <url1> [url2] [url3] ...
fetch() {
    local out_name="$1"
    shift
    local urls=("$@")
    local out="$ASSET_DIR/$out_name"

    if [ -s "$out" ]; then
        echo "[skip] $out_name (already exists, $(wc -c < "$out") bytes)"
        SKIP_COUNT=$((SKIP_COUNT + 1))
        return 0
    fi

    for url in "${urls[@]}"; do
        if curl -fsSL -A "Mozilla/5.0" --retry 2 --retry-delay 1 -o "$out" "$url"; then
            if [ -s "$out" ]; then
                echo "[ok]   $out_name <- $url ($(wc -c < "$out") bytes)"
                SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
                return 0
            fi
        fi
        rm -f "$out"
    done

    echo "[FAIL] $out_name — all URLs failed"
    FAILED_COUNT=$((FAILED_COUNT + 1))
    return 1
}

echo "============================================================"
echo "Fetching shaders into $ASSET_DIR"
echo "============================================================"
echo ""

# ---------- Anime4K v3.x ----------
echo "== Anime4K v3.x =="
fetch "Anime4K_Clamp_Highlights.glsl" \
    "$DYPHIRE_BASE/Anime4K/glsl/Restore/Anime4K_Clamp_Highlights.glsl"

fetch "Anime4K_Restore_CNN_S.glsl" \
    "$DYPHIRE_BASE/Anime4K/glsl/Restore/Anime4K_Restore_CNN_S.glsl"

fetch "Anime4K_Restore_CNN_M.glsl" \
    "$DYPHIRE_BASE/Anime4K/glsl/Restore/Anime4K_Restore_CNN_M.glsl"

fetch "Anime4K_Restore_CNN_L.glsl" \
    "$DYPHIRE_BASE/Anime4K/glsl/Restore/Anime4K_Restore_CNN_L.glsl"

fetch "Anime4K_Restore_CNN_VL.glsl" \
    "$DYPHIRE_BASE/Anime4K/glsl/Restore/Anime4K_Restore_CNN_VL.glsl"

fetch "Anime4K_Upscale_CNN_x2_S.glsl" \
    "$DYPHIRE_BASE/Anime4K/glsl/Upscale/Anime4K_Upscale_CNN_x2_S.glsl"

fetch "Anime4K_Upscale_CNN_x2_M.glsl" \
    "$DYPHIRE_BASE/Anime4K/glsl/Upscale/Anime4K_Upscale_CNN_x2_M.glsl"

fetch "Anime4K_Upscale_CNN_x2_L.glsl" \
    "$DYPHIRE_BASE/Anime4K/glsl/Upscale/Anime4K_Upscale_CNN_x2_L.glsl"

fetch "Anime4K_Upscale_CNN_x2_VL.glsl" \
    "$DYPHIRE_BASE/Anime4K/glsl/Upscale/Anime4K_Upscale_CNN_x2_VL.glsl"

fetch "Anime4K_Upscale_Denoise_CNN_x2_S.glsl" \
    "$DYPHIRE_BASE/Anime4K/glsl/Upscale+Denoise/Anime4K_Upscale_Denoise_CNN_x2_S.glsl"

fetch "Anime4K_Upscale_Denoise_CNN_x2_M.glsl" \
    "$DYPHIRE_BASE/Anime4K/glsl/Upscale+Denoise/Anime4K_Upscale_Denoise_CNN_x2_M.glsl"

fetch "Anime4K_Upscale_Denoise_CNN_x2_L.glsl" \
    "$DYPHIRE_BASE/Anime4K/glsl/Upscale+Denoise/Anime4K_Upscale_Denoise_CNN_x2_L.glsl"

fetch "Anime4K_Upscale_Denoise_CNN_x2_VL.glsl" \
    "$DYPHIRE_BASE/Anime4K/glsl/Upscale+Denoise/Anime4K_Upscale_Denoise_CNN_x2_VL.glsl"

fetch "Anime4K_Denoise_Bilateral_Mode.glsl" \
    "$DYPHIRE_BASE/Anime4K/glsl/Denoise/Anime4K_Denoise_Bilateral_Mode.glsl"

# ---------- FSRCNNX ----------
echo ""
echo "== FSRCNNX =="
fetch "FSRCNNX_x2_8-0-4-1.glsl" \
    "$DYPHIRE_BASE/igv/FSRCNNX_x2_8-0-4-1.glsl"

fetch "FSRCNNX_x2_16-0-4-1.glsl" \
    "$DYPHIRE_BASE/igv/FSRCNNX_x2_16-0-4-1.glsl"

# ---------- ArtCNN ----------
# The exact file "ArtCNN_C4F32_Depth_toToSpace.glsl" is no longer in upstream repos.
# Use the Ani4K_ArtCNN variant from dyphire mirror — same ArtCNN architecture, just renamed.
# It's saved under the original filename so ShaderPresets.kt picks it up correctly.
echo ""
echo "== ArtCNN (using Ani4K_ArtCNN_C4F32_i2 variant) =="
fetch "ArtCNN_C4F32_Depth_toToSpace.glsl" \
    "$DYPHIRE_BASE/Ani4k/Ani4Kv2_ArtCNN_C4F32_i2.glsl"

# ---------- RAVU ----------
echo ""
echo "== RAVU =="
fetch "ravu-lite-r3.hook" \
    "$BJIN_BASE/ravu-lite-r3.hook"

fetch "ravu-lite-r4.hook" \
    "$BJIN_BASE/ravu-lite-r4.hook"

# ---------- KrigBilateral (chroma upscaler) ----------
echo ""
echo "== KrigBilateral =="
fetch "KrigBilateral.hook" \
    "$KRIG_GIST"

# ---------- SSimDownscaler (high quality downscaler) ----------
echo ""
echo "== SSimDownscaler =="
fetch "SSimDownscaler.hook" \
    "$SSIM_GIST"

# ---------- Summary ----------
echo ""
echo "============================================================"
echo "Summary"
echo "============================================================"
echo "  Success: $SUCCESS_COUNT"
echo "  Skipped: $SKIP_COUNT (already existed)"
echo "  Failed:  $FAILED_COUNT"
echo ""
echo "Total files in $ASSET_DIR:"
ls -1 "$ASSET_DIR" 2>/dev/null | wc -l
echo ""
echo "Files:"
ls -la "$ASSET_DIR" 2>/dev/null

# Only exit non-zero if CRITICAL shaders are missing.
# Critical = the ones referenced by the "default" preset (RAVU Lite r4) and at least one Anime4K preset.
CRITICAL_MISSING=0
for f in "ravu-lite-r4.hook" "Anime4K_Clamp_Highlights.glsl" "Anime4K_Restore_CNN_M.glsl" "Anime4K_Upscale_CNN_x2_M.glsl"; do
    if [ ! -s "$ASSET_DIR/$f" ]; then
        echo "CRITICAL MISSING: $f"
        CRITICAL_MISSING=$((CRITICAL_MISSING + 1))
    fi
done

if [ "$CRITICAL_MISSING" -gt 0 ]; then
    echo ""
    echo "FATAL: $CRITICAL_MISSING critical shader(s) missing — build cannot produce working APK"
    exit 1
fi

echo ""
echo "OK — all critical shaders present (non-critical failures are OK)"
exit 0
